from __future__ import annotations

import tempfile
import unittest
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch

import numpy as np
import pandas as pd

from gpa_stock_radar.analysis import analyse_stocks, market_summary, screen_volume_ratio, valuation_percentiles
from gpa_stock_radar.config import load_settings
from gpa_stock_radar.financials import rank_industry_leaders, report_dates
from gpa_stock_radar.intervals import resample_a_share_minutes
from gpa_stock_radar.migration import create_backup, restore_backup
from gpa_stock_radar.reporting import ExcelReport, plot_volume_candidates
from gpa_stock_radar.service import RadarService
from gpa_stock_radar.sources import AkShareSource, DataSourceError, SourceRouter


def minute_fixture() -> pd.DataFrame:
    morning = pd.date_range("2026-07-20 09:30", periods=120, freq="min")
    afternoon = pd.date_range("2026-07-20 13:00", periods=120, freq="min")
    timestamps = morning.append(afternoon)
    close = 10 + np.arange(len(timestamps)) * 0.01
    return pd.DataFrame(
        {
            "datetime": timestamps,
            "open": close - 0.02,
            "high": close + 0.05,
            "low": close - 0.05,
            "close": close,
            "volume": np.arange(len(timestamps)) + 100,
            "amount": (np.arange(len(timestamps)) + 100) * close,
        }
    )


class IntervalTests(unittest.TestCase):
    def test_session_aware_period_counts(self):
        frame = minute_fixture()
        expected = {1: 240, 2: 120, 17: 16, 50: 6, 120: 2, 180: 2, 240: 1}
        for period, count in expected.items():
            with self.subTest(period=period):
                bars = resample_a_share_minutes(frame, period)
                self.assertEqual(len(bars), count)
        bars17 = resample_a_share_minutes(frame, 17)
        self.assertEqual(int(bars17["is_structural_partial"].sum()), 2)
        bars240 = resample_a_share_minutes(frame, 240)
        self.assertEqual(int(bars240.iloc[0]["volume"]), int(frame["volume"].sum()))


class ScreeningTests(unittest.TestCase):
    def setUp(self):
        self.settings = load_settings(Path("/nonexistent/config.yaml"))

    def test_threshold_is_inclusive(self):
        raw = pd.DataFrame(
            {
                "code": ["000001", "000002", "000003"],
                "name": ["甲", "乙", "丙"],
                "price": [10, 10, 10],
                "change_pct": [1, -1, 2],
                "volume_ratio": [4.9, 4.89, 5.0],
                "turnover_pct": [3, 2, 4],
                "amount": [1e8, 1e8, 2e8],
            }
        )
        analysed = analyse_stocks(raw, self.settings)
        selected = screen_volume_ratio(analysed, self.settings, datetime(2026, 7, 20, 10, 0))
        self.assertEqual(set(selected["code"]), {"000001", "000003"})

    def test_valuation_percentile(self):
        history = pd.DataFrame(
            {
                "code": ["801010"] * 4,
                "name": ["农林牧渔"] * 4,
                "date": pd.date_range("2026-01-01", periods=4),
                "pe": [10, 20, 30, 40],
                "pb": [1, 1, 1, 1],
            }
        )
        result = valuation_percentiles(history)
        self.assertEqual(result.iloc[0]["pe_percentile"], 100.0)
        self.assertEqual(result.iloc[0]["signal"], "坏/高估")


class DataSourceFallbackTests(unittest.TestCase):
    def setUp(self):
        with patch.dict("os.environ", {"GPA_PROFILE": "overseas"}):
            self.settings = load_settings(Path("/nonexistent/config.yaml"))

    def test_sina_fields_are_not_mislabelled_or_fabricated(self):
        raw = pd.DataFrame(
            {
                "代码": ["sh600000", "sz000001"],
                "名称": ["浦发银行", "平安银行"],
                "最新价": [10.0, 12.0],
                "涨跌幅": [1.0, -1.0],
                "成交量": [123456, 654321],
                "成交额": [1.2e8, 1.5e8],
            }
        )
        fake_ak = type("FakeAk", (), {"stock_zh_a_spot": staticmethod(lambda: raw)})()
        source = AkShareSource(self.settings)
        source._ak = lambda: fake_ak
        frame = source.stock_spot_sina()

        self.assertEqual(frame["code"].tolist(), ["600000", "000001"])
        self.assertEqual(frame["volume_shares"].tolist(), [123456, 654321])
        self.assertTrue(frame["volume_ratio"].isna().all())
        self.assertTrue(frame["turnover_pct"].isna().all())
        self.assertTrue(frame["data_source"].eq("sina").all())

        analysed = analyse_stocks(frame, self.settings)
        self.assertTrue(analysed["score_confidence"].eq("低").all())
        self.assertFalse(analysed["reason"].str.contains("nan", case=False).any())
        self.assertTrue(screen_volume_ratio(analysed, self.settings).empty)

    def test_overseas_keeps_sina_when_enrichment_fails(self):
        self.settings.raw["source"]["minimum_stock_rows"] = 2
        router = SourceRouter(self.settings)
        router.akshare.stock_spot_eastmoney = Mock(
            side_effect=DataSourceError("海外出口被断开")
        )
        router.akshare.stock_spot_sina = Mock(
            return_value=pd.DataFrame(
                {
                    "code": ["600000", "000001"],
                    "price": [10.0, 12.0],
                    "volume_ratio": [np.nan, np.nan],
                }
            )
        )
        snapshot = router.stock_snapshot()
        self.assertEqual(snapshot.provider, "sina")
        self.assertEqual(snapshot.quality, "basic")
        self.assertFalse(snapshot.volume_ratio_available)
        self.assertIn("海外出口被断开", snapshot.errors[0])

    def test_overseas_uses_enrichment_when_it_recovers(self):
        self.settings.raw["source"]["minimum_stock_rows"] = 2
        router = SourceRouter(self.settings)
        router.akshare.stock_spot_sina = Mock(
            return_value=pd.DataFrame(
                {"code": ["600000", "000001"], "volume_ratio": [np.nan, np.nan]}
            )
        )
        router.akshare.stock_spot_eastmoney = Mock(
            return_value=pd.DataFrame(
                {"code": ["600000", "000001"], "volume_ratio": [5.1, 1.2]}
            )
        )
        snapshot = router.stock_snapshot()
        self.assertEqual(snapshot.provider, "eastmoney")
        self.assertTrue(snapshot.volume_ratio_available)
        router.akshare.stock_spot_sina.assert_called_once()
        router.akshare.stock_spot_eastmoney.assert_called_once()

    def test_china_profile_tries_eastmoney_first(self):
        with patch.dict("os.environ", {"GPA_PROFILE": "china"}):
            settings = load_settings(Path("/nonexistent/config.yaml"))
        self.assertEqual(settings.get("app.deployment_profile"), "china")
        self.assertEqual(
            settings.get("source.stock_provider_order"), ["eastmoney", "sina"]
        )
        settings.raw["source"]["minimum_stock_rows"] = 2
        router = SourceRouter(settings)
        call_order: list[str] = []
        router.akshare.stock_spot_eastmoney = Mock(
            side_effect=lambda: call_order.append("eastmoney")
            or (_ for _ in ()).throw(DataSourceError("临时失败"))
        )
        router.akshare.stock_spot_sina = Mock(
            side_effect=lambda: call_order.append("sina")
            or pd.DataFrame(
                {"code": ["600000", "000001"], "volume_ratio": [np.nan, np.nan]}
            )
        )
        snapshot = router.stock_snapshot()
        self.assertEqual(call_order, ["eastmoney", "sina"])
        self.assertEqual(snapshot.provider, "sina")

    def test_live_failure_keeps_cache_timestamp_and_marks_stale(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config_path = root / "config.yaml"
            config_path.write_text(
                "paths:\n"
                f"  data_dir: {root / 'data'}\n"
                f"  report_dir: {root / 'reports'}\n"
                f"  log_dir: {root / 'logs'}\n",
                encoding="utf-8",
            )
            service = RadarService(load_settings(config_path))
            stocks = analyse_stocks(
                pd.DataFrame(
                    {
                        "code": ["000001"],
                        "name": ["缓存样本"],
                        "price": [10.0],
                        "change_pct": [1.0],
                        "volume_ratio": [5.0],
                        "turnover_pct": [2.0],
                        "amount": [1e8],
                        "fetched_at": ["2026-07-21T10:00:00+08:00"],
                    }
                ),
                service.settings,
            )
            summary = market_summary(stocks)
            summary["data_as_of"] = "2026-07-21T10:00:00+08:00"
            service.storage.save_market(
                stocks,
                screen_volume_ratio(stocks, service.settings),
                pd.DataFrame(),
                pd.DataFrame(),
                summary,
                {},
            )
            before = service.storage.read_snapshot()["updated_at"]
            service.sources.stock_snapshot = Mock(
                side_effect=DataSourceError("两个实时源都失败")
            )

            result = service.collect_once(generate_outputs=False)
            after = service.storage.read_snapshot()
            self.assertTrue(result["cached"])
            self.assertIsNone(result["candidate_count"])
            self.assertEqual(after["updated_at"], before)
            self.assertEqual(after["health"]["stock_spot"]["status"], "cache")
            self.assertEqual(after["health"]["volume_ratio"]["status"], "stale")


class FinancialTests(unittest.TestCase):
    def test_report_dates(self):
        values = report_dates(date(2026, 7, 21), 4)
        self.assertEqual(values[:3], ["20260630", "20260331", "20251231"])

    def test_strong_company_ranks_first(self):
        settings = load_settings(Path("/nonexistent/config.yaml"))
        financial = pd.DataFrame(
            {
                "code": ["000001", "000002", "000003"],
                "name": ["强公司", "普通公司", "弱公司"],
                "industry": ["测试行业"] * 3,
                "report_date": ["20260630"] * 3,
                "revenue": [300, 200, 100],
                "net_profit": [30, 10, -5],
                "revenue_yoy_pct": [30, 10, -10],
                "profit_yoy_pct": [40, 5, -30],
                "revenue_qoq_pct": [10, 2, -5],
                "profit_qoq_pct": [12, 1, -10],
                "roe_pct": [20, 10, -5],
                "gross_margin_pct": [50, 30, 10],
                "operating_cash_per_share": [2, 0.5, -1],
                "net_asset_per_share": [10, 5, -1],
            }
        )
        market = pd.DataFrame(
            {
                "code": ["000001", "000002", "000003"],
                "market_cap": [1000, 500, 100],
                "pe_dynamic": [15, 20, -5],
                "pb": [2, 3, -1],
                "change_60d_pct": [20, 5, -20],
            }
        )
        ranked = rank_industry_leaders(financial, settings, market)
        leader = ranked.loc[ranked["industry_rank"].eq(1)].iloc[0]
        self.assertEqual(leader["code"], "000001")
        self.assertEqual(leader["leader_type"], "综合龙头")


class ReportTests(unittest.TestCase):
    def test_excel_and_jpg_are_created(self):
        settings = load_settings(Path("/nonexistent/config.yaml"))
        candidates = analyse_stocks(
            pd.DataFrame(
                {
                    "code": ["000001"], "name": ["示例"], "price": [10.5],
                    "change_pct": [2.0], "volume_ratio": [5.1], "turnover_pct": [3.0],
                    "amount": [2e8], "market_cap": [5e10],
                }
            ),
            settings,
        )
        candidates = screen_volume_ratio(candidates, settings, datetime(2026, 7, 20, 10, 0))
        boards = pd.DataFrame(
            {"name": ["测试"], "score": [80.0], "change_pct": [2.0], "signal": ["好/偏强"], "breadth_pct": [70.0]}
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            xlsx = root / "demo.xlsx"
            jpg = root / "demo.jpg"
            ExcelReport(settings).write_daily(xlsx, {"count": 1}, candidates, candidates, boards, boards)
            plot_volume_candidates(candidates, jpg, 4.9)
            self.assertGreater(xlsx.stat().st_size, 5000)
            self.assertGreater(jpg.stat().st_size, 5000)


class MigrationTests(unittest.TestCase):
    def test_core_backup_and_restore(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source_config = root / "source-config"
            source_data = root / "source-data"
            source_reports = source_data / "reports"
            source_config.mkdir()
            source_yaml = source_config / "config.yaml"
            source_yaml.write_text(
                "paths:\n"
                f"  data_dir: {source_data}\n"
                f"  report_dir: {source_reports}\n"
                f"  log_dir: {root / 'source-log'}\n",
                encoding="utf-8",
            )
            source_settings = load_settings(source_yaml)
            source_settings.ensure_directories()
            database = source_data / "db" / "market.sqlite3"
            with sqlite3.connect(database) as connection:
                connection.execute("CREATE TABLE sample(value TEXT)")
                connection.execute("INSERT INTO sample VALUES ('迁移成功')")
            (source_config / "secrets.env").write_text("TUSHARE_TOKEN=test-only\n", encoding="utf-8")
            (source_reports / "latest" / "marker.txt").write_text("report", encoding="utf-8")

            archive, checksum = create_backup(
                source_settings, "core", root / "backup.tar.zst", include_secrets=False
            )
            self.assertTrue(archive.exists())
            self.assertTrue(checksum.exists())

            target_config = root / "target-config"
            target_data = root / "target-data"
            target_config.mkdir()
            target_yaml = target_config / "config.yaml"
            target_yaml.write_text(
                "paths:\n"
                f"  data_dir: {target_data}\n"
                f"  report_dir: {target_data / 'reports'}\n"
                f"  log_dir: {root / 'target-log'}\n",
                encoding="utf-8",
            )
            target_settings = load_settings(target_yaml)
            target_settings.ensure_directories()
            manifest = restore_backup(target_settings, archive)
            self.assertEqual(manifest["mode"], "core")
            with sqlite3.connect(target_data / "db" / "market.sqlite3") as connection:
                value = connection.execute("SELECT value FROM sample").fetchone()[0]
            self.assertEqual(value, "迁移成功")
            self.assertFalse((target_config / "secrets.env").exists())


if __name__ == "__main__":
    unittest.main()
