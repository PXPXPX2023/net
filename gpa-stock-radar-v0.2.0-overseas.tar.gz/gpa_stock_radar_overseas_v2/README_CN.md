# GPA A股雷达 v0.2.0：海外版与中国境内版

这是重新整理的完整安装版，不需要先安装 v0.1.x，也不需要手工修改 Python 文件。Debian 12 无需更换系统。

## 选择哪个安装包

| 安装包 | 适用位置 | 行情策略 | 默认轮询 |
|---|---|---|---:|
| 海外版 `overseas` | 美国、欧洲等境外 VPS | 先取得新浪全市场基础行情，再机会性尝试东方财富增强行情 | 300 秒 |
| 中国境内版 `china` | 中国大陆网络环境的 VPS/服务器 | 东方财富增强行情优先，新浪基础行情备用 | 60 秒；降级后 300 秒 |

两个安装包功能相同，区别只有网络数据源顺序、失败冷却和轮询频率。它们使用同一个 `gpa` 命令以及相同的数据目录，因此一般是一台 VPS 选择一个版本，不建议在同一台机器同时运行两个版本。

## 全新安装

把对应的 `.tar.gz` 和 `.sha256` 上传到 `/root/`，先校验，再解压。

海外 VPS 已经装过 GPA 时：

```bash
cd /root
sha256sum -c gpa-stock-radar-v0.2.0-overseas.tar.gz.sha256
tar -xzf gpa-stock-radar-v0.2.0-overseas.tar.gz
cd gpa_stock_radar_overseas_v2
bash install.sh --skip-apt --fresh-config
```

中国境内的新 Debian 12 VPS：

```bash
cd /root
sha256sum -c gpa-stock-radar-v0.2.0-china.tar.gz.sha256
tar -xzf gpa-stock-radar-v0.2.0-china.tar.gz
cd gpa_stock_radar_china_v2
bash install.sh --fresh-config
```

`--fresh-config` 会先备份原来的主配置和评分配置，再安装正确的区域配置。它不会删除数据库、历史报告、自选股或 `TUSHARE_TOKEN`。

如果 Debian 软件依赖已经安装好，可加 `--skip-apt`，避免再次运行 `apt update`。如果想先测试、不立即启动后台服务，可加 `--no-start`。

## 安装后只记这几个命令

```bash
gpa profile
gpa doctor --network
sudo -u gparadar gpa once
gpa
sudo -u gparadar gpa daily
gpa files
```

- `gpa profile`：确认当前是海外版还是中国境内版。
- `gpa doctor --network`：检查依赖、目录和实际网络数据源。
- `gpa once`：立即采集一次并生成实时 Excel/JPG。
- `gpa`：打开 SSH 实时分析界面，`Ctrl+C` 退出。
- `gpa daily`：生成盘后完整 Excel。
- `gpa finance`：更新年报、半年报、季报并筛选行业龙头。
- `gpa backup --full`：生成完整迁移包。

报告固定在：

```text
/var/lib/gpa-stock-radar/reports/latest/
```

## 数据源真实性规则

东方财富增强源成功时，可使用量比、换手率、动态 PE、PB、市值、板块、估值和相关增强字段。

新浪基础源成功时，只使用它真实提供的代码、名称、最新价、涨跌、开高低、成交量额等字段。新浪没有提供的量比、换手率和估值字段保持为空：

- 量比筛选显示“未执行”，不会显示成真实的 0 只；
- `candidate_count` 返回 `null`；
- SSH、Excel 和 JPG 都显示当前提供方、字段质量和缺失字段；
- 缺失数据不会被填成 0，也不会自行猜测。

如果所有实时源都失败，程序只保留旧缓存及其原始时间，并隐藏旧量比候选，避免把昨天的数据当成今天的实时预警。

## 已包含的主要模块

- A 股全市场涨跌、成交和市场广度；
- 量比不小于 4.9 的真实字段筛选；
- 行业、概念板块强弱对比；
- 1、2、5、10、12、15、17、20、30、40、50、60、120、180、240 分钟周期；
- 自选股与候选股分钟数据；
- 年报、半年报、一季报、三季报分析；
- 同行业财报龙头、成长龙头、质量龙头、现金流龙头排名；
- 申万一级行业 PE 历史分位；
- SSH 实时界面、盘中 Excel/JPG、盘后完整 Excel；
- 数据健康、过期和低置信度提示；
- 完整迁移备份及 SHA256 校验。

颜色规则：好/偏强为蓝色，坏/偏弱为白色，中性为灰色，接口异常、数据缺失或低置信度为橙色；每项同时保留文字标签。

## 目录和迁移

```text
/opt/gpa-stock-radar/                 程序与 Python 虚拟环境
/etc/gpa-stock-radar/                 配置、自选股和 Token
/etc/gpa-stock-radar/backups/         --fresh-config 自动生成的旧配置备份
/var/lib/gpa-stock-radar/             数据库、分钟线、财报和报告
/var/lib/gpa-stock-radar/reports/latest/  SFTP 固定取件目录
/var/log/gpa-stock-radar/             日志目录
```

迁移到另一台 VPS：

```bash
sudo -u gparadar gpa backup --full
```

在新 VPS 安装对应区域版本时使用：

```bash
bash install.sh --restore /上传位置/gpa_full_时间.tar.zst
```

## 重要边界

免费行情是轮询近实时，不是交易所授权 Level-2，不适合自动下单。中国境内版也不能保证任何公开网站永远可访问；海外版则不能凭基础行情凭空恢复量比、板块和财报字段。程序的原则是宁可显示“不可用”，也不生成看似完整的假数据。

本工具只用于研究、筛选和复盘，不构成投资建议。
