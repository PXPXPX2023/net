from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import timedelta
from pathlib import Path
from typing import Iterator

import pandas as pd

from .config import Settings
from .util import atomic_json, now_cn, read_json, records_ready


class RadarStorage:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.settings.ensure_directories()
        self.db_path = settings.data_dir / "db" / "market.sqlite3"
        self.cache_path = settings.data_dir / "cache" / "live_snapshot.json"
        self.health_path = settings.data_dir / "state" / "health.json"
        self._initialise()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _initialise(self) -> None:
        with self.connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS volume_signal_history (
                    observed_at TEXT NOT NULL,
                    trade_date TEXT NOT NULL,
                    code TEXT NOT NULL,
                    name TEXT,
                    price REAL,
                    change_pct REAL,
                    volume_ratio REAL,
                    turnover_pct REAL,
                    amount REAL,
                    score REAL,
                    signal TEXT,
                    risk TEXT,
                    PRIMARY KEY (observed_at, code)
                );
                CREATE TABLE IF NOT EXISTS volume_signal_state (
                    trade_date TEXT NOT NULL,
                    code TEXT NOT NULL,
                    name TEXT,
                    first_trigger_at TEXT NOT NULL,
                    last_trigger_at TEXT NOT NULL,
                    current_ratio REAL,
                    max_ratio REAL,
                    current_change_pct REAL,
                    max_change_pct REAL,
                    PRIMARY KEY (trade_date, code)
                );
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                """
            )

    def save_market(
        self,
        stocks: pd.DataFrame,
        candidates: pd.DataFrame,
        industries: pd.DataFrame,
        concepts: pd.DataFrame,
        summary: dict,
        health: dict,
    ) -> None:
        observed = now_cn()
        with self.connect() as connection:
            stocks.to_sql("stock_latest", connection, if_exists="replace", index=False)
            if len(industries.columns) > 0:
                industries.to_sql("industry_latest", connection, if_exists="replace", index=False)
            if len(concepts.columns) > 0:
                concepts.to_sql("concept_latest", connection, if_exists="replace", index=False)
            history_columns = [
                "code", "name", "price", "change_pct", "volume_ratio", "turnover_pct",
                "amount", "score", "signal", "risk",
            ]
            if not candidates.empty:
                history = candidates.reindex(columns=history_columns).copy()
                history.insert(0, "trade_date", observed.date().isoformat())
                history.insert(0, "observed_at", observed.isoformat())
                history.to_sql("volume_signal_history", connection, if_exists="append", index=False)
                for row in history.to_dict(orient="records"):
                    connection.execute(
                        """
                        INSERT INTO volume_signal_state (
                            trade_date, code, name, first_trigger_at, last_trigger_at,
                            current_ratio, max_ratio, current_change_pct, max_change_pct
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(trade_date, code) DO UPDATE SET
                            name=excluded.name,
                            last_trigger_at=excluded.last_trigger_at,
                            current_ratio=excluded.current_ratio,
                            max_ratio=MAX(volume_signal_state.max_ratio, excluded.max_ratio),
                            current_change_pct=excluded.current_change_pct,
                            max_change_pct=MAX(volume_signal_state.max_change_pct, excluded.max_change_pct)
                        """,
                        (
                            row["trade_date"], row["code"], row.get("name"), row["observed_at"],
                            row["observed_at"], row.get("volume_ratio"), row.get("volume_ratio"),
                            row.get("change_pct"), row.get("change_pct"),
                        ),
                    )
            connection.execute(
                "INSERT OR REPLACE INTO metadata(key, value, updated_at) VALUES (?, ?, ?)",
                ("market_summary", json.dumps(summary, ensure_ascii=False), observed.isoformat()),
            )

        payload = {
            "schema_version": 2,
            "updated_at": observed.isoformat(),
            "data_as_of": summary.get("data_as_of", observed.isoformat()),
            "threshold": self.settings.threshold,
            "summary": summary,
            "volume_candidates": records_ready(candidates),
            "industries": records_ready(industries),
            "concepts": records_ready(concepts),
            "health": health,
        }
        atomic_json(self.cache_path, payload)
        atomic_json(self.health_path, health)
        self.cleanup_history()

    def read_snapshot(self) -> dict:
        return read_json(self.cache_path, {})

    def read_health(self) -> dict:
        return read_json(self.health_path, {})

    def update_health(self, health: dict) -> None:
        payload = self.read_snapshot()
        if not payload:
            self.write_health(health)
            return
        payload["health"] = health
        payload["updated_at"] = payload.get("updated_at", now_cn().isoformat())
        atomic_json(self.cache_path, payload)
        self.write_health(health)

    def write_health(self, health: dict) -> None:
        atomic_json(self.health_path, health)

    def read_table(self, table: str) -> pd.DataFrame:
        allowed = {"stock_latest", "industry_latest", "concept_latest", "volume_signal_state"}
        if table not in allowed:
            raise ValueError(f"不允许读取表: {table}")
        try:
            with self.connect() as connection:
                return pd.read_sql_query(f'SELECT * FROM "{table}"', connection)
        except (sqlite3.Error, pd.errors.DatabaseError):
            return pd.DataFrame()

    def save_minute(self, code: str, frame: pd.DataFrame) -> Path:
        target = self.settings.data_dir / "minute" / f"{str(code).zfill(6)}.csv.gz"
        if target.exists():
            try:
                previous = pd.read_csv(target, compression="gzip")
                frame = pd.concat([previous, frame], ignore_index=True)
            except Exception:
                pass
        frame = frame.drop_duplicates(subset=["datetime"], keep="last").sort_values("datetime")
        cutoff = now_cn().date() - timedelta(days=int(self.settings.get("storage.watchlist_minutes_days", 365)))
        timestamps = pd.to_datetime(frame["datetime"], errors="coerce")
        frame = frame.loc[timestamps.dt.date >= cutoff].copy()
        temporary = target.with_suffix(".tmp.gz")
        frame.to_csv(temporary, index=False, compression="gzip")
        temporary.replace(target)
        return target

    def load_minute(self, code: str) -> pd.DataFrame:
        target = self.settings.data_dir / "minute" / f"{str(code).zfill(6)}.csv.gz"
        if not target.exists():
            return pd.DataFrame()
        result = pd.read_csv(target, compression="gzip")
        if "datetime" in result:
            result["datetime"] = pd.to_datetime(result["datetime"], errors="coerce")
        return result

    def cleanup_history(self) -> None:
        cutoff = (now_cn() - timedelta(days=10)).isoformat()
        with self.connect() as connection:
            connection.execute("DELETE FROM volume_signal_history WHERE observed_at < ?", (cutoff,))
