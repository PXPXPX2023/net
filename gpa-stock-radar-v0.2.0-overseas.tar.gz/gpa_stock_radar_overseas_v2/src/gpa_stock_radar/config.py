from __future__ import annotations

import copy
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG = Path("/etc/gpa-stock-radar/config.yaml")
DEFAULT_SCORING = Path("/etc/gpa-stock-radar/scoring.yaml")


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in overlay.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _app_roots() -> list[Path]:
    return [
        Path(os.getenv("GPA_APP_DIR", "/opt/gpa-stock-radar/app")),
        Path(__file__).resolve().parents[2],
    ]


def bundle_profile() -> str:
    override = os.getenv("GPA_PROFILE", "").strip().lower()
    if override:
        if override not in {"overseas", "china"}:
            raise ValueError("GPA_PROFILE 只能是 overseas 或 china")
        return override
    for root in _app_roots():
        marker = root / "BUNDLE_PROFILE"
        if marker.exists():
            value = marker.read_text(encoding="utf-8", errors="replace").strip().lower()
            if value in {"overseas", "china"}:
                return value
    return "overseas"


def _package_config(name: str) -> Path:
    profile = bundle_profile()
    candidates: list[Path] = []
    for root in _app_roots():
        candidates.extend(
            [
                root / "profiles" / profile / name,
                root / "config" / name,
            ]
        )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return candidates[-1]


def _read_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle) or {}
    if not isinstance(value, dict):
        raise ValueError(f"配置文件顶层必须是对象: {path}")
    return value


@dataclass(frozen=True)
class Settings:
    raw: dict[str, Any]
    config_path: Path
    scoring: dict[str, Any]

    def get(self, dotted: str, default: Any = None) -> Any:
        current: Any = self.raw
        for part in dotted.split("."):
            if not isinstance(current, dict) or part not in current:
                return default
            current = current[part]
        return current

    @property
    def data_dir(self) -> Path:
        override = os.getenv("GPA_DATA_DIR")
        return Path(override or self.get("paths.data_dir", "/var/lib/gpa-stock-radar"))

    @property
    def report_dir(self) -> Path:
        override = os.getenv("GPA_REPORT_DIR")
        return Path(override or self.get("paths.report_dir", self.data_dir / "reports"))

    @property
    def log_dir(self) -> Path:
        override = os.getenv("GPA_LOG_DIR")
        return Path(override or self.get("paths.log_dir", "/var/log/gpa-stock-radar"))

    @property
    def threshold(self) -> float:
        return float(self.get("market.volume_ratio_threshold", 4.9))

    @property
    def periods(self) -> list[int]:
        return [int(item) for item in self.get("market.custom_periods_minutes", [])]

    def ensure_directories(self) -> None:
        for path in (
            self.data_dir,
            self.data_dir / "db",
            self.data_dir / "cache",
            self.data_dir / "minute",
            self.data_dir / "financial",
            self.data_dir / "state",
            self.data_dir / "backups",
            self.report_dir / "latest",
            self.report_dir / "daily",
            self.report_dir / "financial",
            self.log_dir,
        ):
            path.mkdir(parents=True, exist_ok=True)


def load_settings(config_path: str | Path | None = None) -> Settings:
    package_base = _read_yaml(_package_config("config.yaml"))
    selected = Path(config_path or os.getenv("GPA_CONFIG", DEFAULT_CONFIG))
    user = _read_yaml(selected)
    scoring_path = Path(os.getenv("GPA_SCORING", DEFAULT_SCORING))
    scoring = _deep_merge(
        _read_yaml(_package_config("scoring.yaml")), _read_yaml(scoring_path)
    )
    settings = Settings(_deep_merge(package_base, user), selected, scoring)
    return settings
