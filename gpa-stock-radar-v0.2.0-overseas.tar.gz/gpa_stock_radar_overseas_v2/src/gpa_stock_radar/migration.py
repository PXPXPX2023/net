from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import tarfile
import tempfile
from pathlib import Path

import zstandard as zstd

from . import __version__
from .config import Settings
from .util import now_cn


class MigrationError(RuntimeError):
    pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy_sqlite(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    source_connection = sqlite3.connect(f"file:{source}?mode=ro", uri=True)
    target_connection = sqlite3.connect(target)
    try:
        source_connection.backup(target_connection)
    finally:
        target_connection.close()
        source_connection.close()


def _copy_tree(source: Path, target: Path, ignore_names: set[str] | None = None) -> None:
    if not source.exists():
        return
    ignore_names = ignore_names or set()
    for item in source.rglob("*"):
        relative = item.relative_to(source)
        if any(part in ignore_names for part in relative.parts):
            continue
        destination = target / relative
        if item.is_symlink():
            continue
        if item.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
        elif item.name.endswith((".sqlite3-wal", ".sqlite3-shm")):
            continue
        elif item.suffix == ".sqlite3":
            _copy_sqlite(item, destination)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, destination)


def create_backup(
    settings: Settings,
    mode: str = "core",
    output: Path | None = None,
    include_secrets: bool = True,
) -> tuple[Path, Path]:
    if mode not in {"core", "full"}:
        raise MigrationError("备份模式只能是 core 或 full")
    timestamp = now_cn().strftime("%Y%m%d_%H%M%S")
    output = (output or settings.data_dir / "backups" / f"gpa_{mode}_{timestamp}.tar.zst").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise MigrationError(f"目标已存在，不会覆盖: {output}")

    with tempfile.TemporaryDirectory(prefix="gpa-backup-") as temporary:
        stage = Path(temporary) / "gpa-backup"
        stage.mkdir()
        config_target = stage / "config"
        config_target.mkdir()
        config_source = settings.config_path.parent
        if config_source.exists():
            for item in config_source.iterdir():
                if item.is_file() and not item.is_symlink():
                    if not include_secrets and item.name == "secrets.env":
                        continue
                    shutil.copy2(item, config_target / item.name)

        data_target = stage / "data"
        data_target.mkdir()
        if mode == "full":
            _copy_tree(settings.data_dir, data_target, {"backups"})
        else:
            for name in ("db", "financial", "state"):
                _copy_tree(settings.data_dir / name, data_target / name)
            _copy_tree(settings.report_dir / "latest", data_target / "reports" / "latest")

        manifest = {
            "format": "gpa-stock-radar-backup-v1",
            "app_version": __version__,
            "deployment_profile": settings.get("app.deployment_profile", "overseas"),
            "created_at": now_cn().isoformat(),
            "mode": mode,
            "includes_secrets": include_secrets,
            "source_paths": {
                "config": str(config_source),
                "data": str(settings.data_dir),
            },
            "restore_note": "先上传本程序安装包和该备份，再执行 bash install.sh --restore <备份文件>",
        }
        (stage / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary_tar = Path(temporary) / "backup.tar"
        with tarfile.open(temporary_tar, "w") as archive:
            archive.add(stage, arcname="gpa-backup", recursive=True)
        temporary_output = output.with_name(f".{output.name}.tmp")
        try:
            compressor = zstd.ZstdCompressor(level=6, threads=-1)
            with temporary_tar.open("rb") as source_handle, temporary_output.open("wb") as output_handle:
                compressor.copy_stream(source_handle, output_handle)
            os.replace(temporary_output, output)
        finally:
            temporary_output.unlink(missing_ok=True)

    checksum = _sha256(output)
    checksum_path = output.with_name(output.name + ".sha256")
    checksum_path.write_text(f"{checksum}  {output.name}\n", encoding="utf-8")
    try:
        os.chmod(output, 0o640)
        os.chmod(checksum_path, 0o640)
    except PermissionError:
        pass
    return output, checksum_path


def _validate_members(members: list[tarfile.TarInfo]) -> None:
    for member in members:
        path = Path(member.name)
        if path.is_absolute() or ".." in path.parts or not path.parts or path.parts[0] != "gpa-backup":
            raise MigrationError(f"备份含不安全路径: {member.name}")
        if member.issym() or member.islnk() or member.isdev():
            raise MigrationError(f"备份含不允许的链接或设备文件: {member.name}")


def restore_backup(settings: Settings, archive: Path, verify_checksum: bool = True) -> dict:
    archive = archive.resolve()
    if not archive.is_file():
        raise MigrationError(f"找不到备份文件: {archive}")
    checksum_path = archive.with_name(archive.name + ".sha256")
    if verify_checksum and checksum_path.exists():
        expected = checksum_path.read_text(encoding="utf-8").split()[0]
        actual = _sha256(archive)
        if expected != actual:
            raise MigrationError("SHA256 校验失败，备份可能损坏")
    with tempfile.TemporaryDirectory(prefix="gpa-restore-") as temporary:
        temporary_root = Path(temporary)
        tar_path = temporary_root / "backup.tar"
        try:
            decompressor = zstd.ZstdDecompressor()
            with archive.open("rb") as source_handle, tar_path.open("wb") as output_handle:
                decompressor.copy_stream(source_handle, output_handle)
        except zstd.ZstdError as exc:
            raise MigrationError(f"Zstandard 解压失败: {exc}") from exc
        try:
            with tarfile.open(tar_path, "r") as tar:
                members = tar.getmembers()
                _validate_members(members)
                tar.extractall(temporary_root, members=members, filter="data")
        except (tarfile.TarError, OSError) as exc:
            raise MigrationError(f"tar 解包失败: {exc}") from exc
        root = temporary_root / "gpa-backup"
        manifest_path = root / "manifest.json"
        if not manifest_path.exists():
            raise MigrationError("备份缺少 manifest.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("format") != "gpa-stock-radar-backup-v1":
            raise MigrationError("不是受支持的 GPA 备份格式")
        # Overlay only. Existing files not present in the archive are retained.
        _copy_tree(root / "config", settings.config_path.parent)
        _copy_tree(root / "data", settings.data_dir)
    return manifest
