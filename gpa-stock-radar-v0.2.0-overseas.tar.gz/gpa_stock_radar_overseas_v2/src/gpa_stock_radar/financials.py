from __future__ import annotations

from datetime import date
from typing import Iterable

import numpy as np
import pandas as pd

from .config import Settings


def report_dates(as_of: date | None = None, count: int = 12) -> list[str]:
    """Return recent Chinese reporting period end dates, newest first."""
    today = as_of or date.today()
    current_year = today.year
    values: list[date] = []
    for year in range(current_year, current_year - 5, -1):
        for month, day in ((12, 31), (9, 30), (6, 30), (3, 31)):
            candidate = date(year, month, day)
            if candidate <= today:
                values.append(candidate)
    return [item.strftime("%Y%m%d") for item in sorted(values, reverse=True)[:count]]


def report_kind(report_date: str) -> str:
    suffix = str(report_date)[4:]
    return {
        "0331": "一季报",
        "0630": "半年报",
        "0930": "三季报",
        "1231": "年报",
    }.get(suffix, "定期报告")


def _pct(series: pd.Series, higher_is_better: bool = True) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    valid = numeric.notna()
    if valid.sum() <= 1:
        return pd.Series(50.0, index=series.index)
    ranks = numeric.rank(pct=True, ascending=higher_is_better) * 100
    if not higher_is_better:
        ranks = numeric.rank(pct=True, ascending=False) * 100
    return ranks.fillna(50.0)


def _mean_available(parts: Iterable[pd.Series], index: pd.Index) -> pd.Series:
    frame = pd.concat(list(parts), axis=1)
    frame.index = index
    return frame.mean(axis=1, skipna=True).fillna(50.0)


def rank_industry_leaders(
    financial: pd.DataFrame,
    settings: Settings,
    market: pd.DataFrame | None = None,
) -> pd.DataFrame:
    if financial.empty:
        return financial.copy()
    result = financial.copy()
    if market is not None and not market.empty and "code" in market:
        market_columns = [
            column
            for column in ("code", "market_cap", "pe_dynamic", "pb", "change_60d_pct", "change_ytd_pct")
            if column in market.columns
        ]
        result = result.merge(market[market_columns].drop_duplicates("code"), on="code", how="left")

    numeric_columns = (
        "revenue",
        "net_profit",
        "revenue_yoy_pct",
        "profit_yoy_pct",
        "revenue_qoq_pct",
        "profit_qoq_pct",
        "roe_pct",
        "gross_margin_pct",
        "operating_cash_per_share",
        "net_asset_per_share",
        "market_cap",
        "pe_dynamic",
        "pb",
        "change_60d_pct",
    )
    for column in numeric_columns:
        if column not in result:
            result[column] = np.nan
        result[column] = pd.to_numeric(result[column], errors="coerce")
    if "industry" not in result:
        result["industry"] = "未分类"
    result["industry"] = result["industry"].fillna("未分类").astype(str)

    weights = settings.get("financial.weights", {})
    minimum_members = int(settings.get("financial.minimum_industry_members", 3))
    scored: list[pd.DataFrame] = []
    for _, group in result.groupby("industry", dropna=False, sort=False):
        group = group.copy()
        if len(group) < minimum_members:
            group["score_confidence"] = "低"
        else:
            group["score_confidence"] = "高"

        revenue_scale = np.log1p(group["revenue"].clip(lower=0))
        profit_scale = np.log1p(group["net_profit"].clip(lower=0))
        group["score_scale"] = _mean_available(
            [_pct(revenue_scale), _pct(profit_scale), _pct(group["market_cap"])], group.index
        )
        group["score_growth"] = _mean_available(
            [
                _pct(group["revenue_yoy_pct"]),
                _pct(group["profit_yoy_pct"]),
                _pct(group["revenue_qoq_pct"]),
                _pct(group["profit_qoq_pct"]),
            ],
            group.index,
        )
        group["score_quality"] = _mean_available(
            [_pct(group["roe_pct"]), _pct(group["gross_margin_pct"])], group.index
        )
        group["score_cashflow"] = _pct(group["operating_cash_per_share"])
        group["score_safety"] = (
            (group["net_profit"].gt(0).astype(float) * 40)
            + (group["net_asset_per_share"].gt(0).astype(float) * 30)
            + (group["operating_cash_per_share"].ge(0).astype(float) * 30)
        )
        group["score_market"] = _mean_available(
            [_pct(group["market_cap"]), _pct(group["change_60d_pct"])], group.index
        )
        positive_pe = group["pe_dynamic"].where(group["pe_dynamic"] > 0)
        positive_pb = group["pb"].where(group["pb"] > 0)
        group["score_valuation"] = _mean_available(
            [_pct(positive_pe, higher_is_better=False), _pct(positive_pb, higher_is_better=False)],
            group.index,
        )

        total_weight = sum(float(weights.get(key, value)) for key, value in {
            "scale": 20,
            "growth": 20,
            "quality": 20,
            "cashflow": 15,
            "safety": 10,
            "market": 10,
            "valuation": 5,
        }.items())
        group["leader_score"] = (
            group["score_scale"] * float(weights.get("scale", 20))
            + group["score_growth"] * float(weights.get("growth", 20))
            + group["score_quality"] * float(weights.get("quality", 20))
            + group["score_cashflow"] * float(weights.get("cashflow", 15))
            + group["score_safety"] * float(weights.get("safety", 10))
            + group["score_market"] * float(weights.get("market", 10))
            + group["score_valuation"] * float(weights.get("valuation", 5))
        ) / max(total_weight, 1)
        group["leader_score"] = group["leader_score"].round(1)
        group["industry_rank"] = group["leader_score"].rank(method="min", ascending=False).astype(int)

        component_map = {
            "规模龙头": "score_scale",
            "成长龙头": "score_growth",
            "质量龙头": "score_quality",
            "现金流龙头": "score_cashflow",
            "市场龙头": "score_market",
        }
        component_names = list(component_map)
        component_columns = [component_map[name] for name in component_names]
        maxima = group[component_columns].to_numpy().argmax(axis=1)
        group["leader_type"] = [component_names[index] for index in maxima]
        group.loc[group["industry_rank"].eq(1), "leader_type"] = "综合龙头"

        group["risk"] = ""
        group.loc[group["net_profit"].lt(0), "risk"] += "净利润为负；"
        group.loc[group["net_asset_per_share"].lt(0), "risk"] += "负净资产；"
        group.loc[group["operating_cash_per_share"].lt(0), "risk"] += "经营现金流为负；"
        if "name" in group:
            group.loc[group["name"].astype(str).str.contains(r"ST|退", case=False, regex=True), "risk"] += "ST或退市风险；"
        required_quality = group[
            ["revenue", "net_profit", "roe_pct", "operating_cash_per_share"]
        ].notna().mean(axis=1)
        group.loc[required_quality.lt(0.75), "score_confidence"] = "低"
        group["signal"] = np.select(
            [group["leader_score"].ge(60), group["leader_score"].le(40)],
            ["好/偏强", "坏/偏弱"],
            default="中性/观察",
        )
        scored.append(group)

    ranked = pd.concat(scored, ignore_index=True)
    limit = int(settings.get("financial.leaders_per_industry", 10))
    ranked = ranked.loc[ranked["industry_rank"] <= limit].copy()
    if "report_date" in ranked:
        ranked["report_kind"] = ranked["report_date"].astype(str).map(report_kind)
    else:
        ranked["report_kind"] = "定期报告"
    return ranked.sort_values(["industry", "industry_rank", "leader_score"], ascending=[True, True, False])


def financial_trend(history: pd.DataFrame) -> pd.DataFrame:
    """Summarise multi-report consistency for rows already normalised by source."""
    if history.empty or not {"code", "report_date"}.issubset(history.columns):
        return pd.DataFrame()
    work = history.copy()
    work["report_date"] = work["report_date"].astype(str)
    work = work.sort_values(["code", "report_date"])
    rows: list[dict[str, object]] = []
    for code, group in work.groupby("code", sort=False):
        latest = group.iloc[-1]
        profit_positive = pd.to_numeric(group.get("net_profit"), errors="coerce").gt(0)
        revenue_growth = pd.to_numeric(group.get("revenue_yoy_pct"), errors="coerce")
        profit_growth = pd.to_numeric(group.get("profit_yoy_pct"), errors="coerce")
        rows.append(
            {
                "code": code,
                "name": latest.get("name", ""),
                "industry": latest.get("industry", ""),
                "latest_report_date": latest["report_date"],
                "periods": int(len(group)),
                "positive_profit_ratio_pct": round(float(profit_positive.mean() * 100), 1),
                "average_revenue_yoy_pct": round(float(revenue_growth.mean()), 2),
                "average_profit_yoy_pct": round(float(profit_growth.mean()), 2),
                "trend_signal": "好/稳定" if profit_positive.mean() >= 0.75 and profit_growth.mean() > 0 else "坏/需核查",
            }
        )
    return pd.DataFrame(rows)
