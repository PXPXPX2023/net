from __future__ import annotations

import time
from datetime import datetime

from rich import box
from rich.console import Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import Settings
from .storage import RadarStorage
from .util import SHANGHAI, now_cn


def _style(signal: str) -> str:
    if str(signal).startswith("好"):
        return "bright_blue on #081624"
    if str(signal).startswith("坏"):
        return "white on #081624"
    if any(
        word in str(signal).lower()
        for word in ("error", "fallback", "partial", "unavailable", "cache", "stale", "basic", "degraded")
    ):
        return "orange3 on #081624"
    return "grey70 on #081624"


def _age_text(updated_at: str | None, stale_after: int) -> Text:
    if not updated_at:
        return Text("尚无数据", style="orange3")
    try:
        updated = datetime.fromisoformat(updated_at)
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=SHANGHAI)
        seconds = max(0, int((now_cn() - updated.astimezone(SHANGHAI)).total_seconds()))
    except ValueError:
        return Text("时间无效", style="orange3")
    return Text(f"{seconds}秒前", style="orange3" if seconds > stale_after else "bright_blue")


def _summary_table(snapshot: dict) -> Table:
    summary = snapshot.get("summary", {})
    table = Table(box=box.SIMPLE, expand=True, show_header=False, pad_edge=False)
    for _ in range(8):
        table.add_column(justify="center")
    table.add_row(
        "股票数", str(summary.get("count", "—")),
        "上涨", f"[bright_blue]{summary.get('up', '—')}[/]",
        "下跌", f"[white]{summary.get('down', '—')}[/]",
        "上涨占比", f"{summary.get('breadth_pct', '—')}%",
    )
    table.add_row(
        "中位涨幅", f"{summary.get('median_change_pct', '—')}%",
        "成交额", f"{summary.get('total_amount_yi', '—')}亿",
        "近似涨停", str(summary.get("limit_up_approx", "—")),
        "近似跌停", str(summary.get("limit_down_approx", "—")),
    )
    return table


def _candidate_table(snapshot: dict, max_rows: int) -> Table:
    threshold = snapshot.get("threshold", 4.9)
    table = Table(title=f"量比 ≥ {threshold} 实时筛选", box=box.ROUNDED, expand=True, header_style="bold white")
    columns = [
        ("代码", "right"), ("名称", "left"), ("现价", "right"), ("涨幅%", "right"),
        ("量比", "right"), ("换手%", "right"), ("评分", "right"), ("判定", "left"), ("风险", "left"),
    ]
    for label, justify in columns:
        table.add_column(label, justify=justify, no_wrap=True)
    volume_health = snapshot.get("health", {}).get("volume_ratio", {})
    status = str(volume_health.get("status", "")) if isinstance(volume_health, dict) else ""
    rows = (
        []
        if status in {"unavailable", "stale", "error"}
        else snapshot.get("volume_candidates", [])[:max_rows]
    )
    for row in rows:
        style = _style(str(row.get("signal", "")))
        table.add_row(
            str(row.get("code", "")), str(row.get("name", "")), _number(row.get("price")),
            _number(row.get("change_pct")), _number(row.get("volume_ratio")), _number(row.get("turnover_pct")),
            _number(row.get("score"), 1), str(row.get("signal", "")), str(row.get("risk", "")), style=style,
        )
    if not rows:
        if status in {"unavailable", "stale", "error"}:
            message = "量比不可用：筛选未执行（不是0只）"
            style = "orange3"
        else:
            message = "当前没有达到阈值的股票（量比字段已获取并完成筛选）"
            style = "grey70"
        table.add_row("—", message, "", "", "", "", "", "", "", style=style)
    return table


def _number(value, decimals: int = 2) -> str:
    try:
        return f"{float(value):.{decimals}f}"
    except (TypeError, ValueError):
        return "—"


def _board_table(title: str, rows: list[dict], max_rows: int) -> Table:
    table = Table(title=title, box=box.SIMPLE_HEAVY, expand=True, header_style="bold white")
    for label in ("板块", "涨幅%", "上涨占比%", "评分", "判定", "领涨股"):
        table.add_column(label, justify="right" if "%" in label or label == "评分" else "left", no_wrap=True)
    selected = rows[: max_rows // 2] + rows[-(max_rows // 2) :] if len(rows) > max_rows else rows
    for row in selected:
        style = _style(str(row.get("signal", "")))
        table.add_row(
            str(row.get("name", "")), _number(row.get("change_pct")), _number(row.get("breadth_pct")),
            _number(row.get("score"), 1), str(row.get("signal", "")), str(row.get("leader_name", "")), style=style,
        )
    if not rows:
        table.add_row("板块源暂不可用", "", "", "", "", "", style="orange3")
    return table


def _health_table(snapshot: dict) -> Table:
    table = Table(title="数据源与字段状态", box=box.SIMPLE, expand=True, header_style="bold white")
    table.add_column("模块", no_wrap=True)
    table.add_column("状态", no_wrap=True)
    table.add_column("说明", overflow="fold")
    labels = {
        "stock_spot": "全市场",
        "volume_ratio": "量比筛选",
        "industry_spot": "行业板块",
        "concept_spot": "概念板块",
        "priority_minutes": "分钟数据",
    }
    health = snapshot.get("health", {})
    for key, label in labels.items():
        item = health.get(key)
        if not isinstance(item, dict):
            continue
        status = str(item.get("status", "未知"))
        table.add_row(label, status, str(item.get("message", "")), style=_style(status))
    if table.row_count == 0:
        table.add_row("—", "尚无状态", "请先运行 sudo -u gparadar gpa once", style="orange3")
    return table


def render_dashboard(settings: Settings, snapshot: dict):
    age = _age_text(
        snapshot.get("data_as_of") or snapshot.get("updated_at"),
        int(settings.get("source.stale_after_seconds", 180)),
    )
    summary = snapshot.get("summary", {})
    source_name = str(summary.get("data_source_name", "数据源待确认"))
    quality = str(summary.get("data_quality", "unknown"))
    profile = str(settings.get("app.deployment_profile", "overseas"))
    profile_label = "海外版" if profile == "overseas" else "中国境内版"
    header = Text()
    header.append(f"GPA A股实时雷达·{profile_label}  ", style="bold bright_blue")
    header.append("免费轮询近实时 / 非Level-2  ", style="grey70")
    header.append(f"{source_name}({quality})  ", style="orange3" if quality != "enriched" else "bright_blue")
    header.append("数据：")
    header.append_text(age)
    header.append("  退出：Ctrl+C", style="grey70")
    boards = _board_table("行业强弱（头尾对照）", snapshot.get("industries", []), int(settings.get("ui.max_board_rows", 12)))
    parts = [
        Panel(header, border_style="blue"),
        _summary_table(snapshot),
        _health_table(snapshot),
        _candidate_table(snapshot, int(settings.get("ui.max_volume_rows", 25))),
        boards,
    ]
    if bool(settings.get("ui.show_concepts", True)):
        parts.append(_board_table("概念强弱（头尾对照）", snapshot.get("concepts", []), int(settings.get("ui.max_board_rows", 12))))
    content = Group(*parts)
    return content


def run_tui(settings: Settings) -> None:
    storage = RadarStorage(settings)
    refresh = max(1, int(settings.get("ui.refresh_seconds", 3)))

    def current_snapshot() -> dict:
        snapshot = storage.read_snapshot()
        if not snapshot:
            snapshot = {"health": storage.read_health()}
        return snapshot

    with Live(render_dashboard(settings, current_snapshot()), refresh_per_second=1, screen=True) as live:
        try:
            while True:
                live.update(render_dashboard(settings, current_snapshot()), refresh=True)
                time.sleep(refresh)
        except KeyboardInterrupt:
            return
