from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Callable

import pandas as pd

from .config import Settings
from .util import now_cn


class DataSourceError(RuntimeError):
    pass


EASTMONEY_STOCK_COLUMNS = {
    "代码": "code",
    "名称": "name",
    "最新价": "price",
    "涨跌幅": "change_pct",
    "涨跌额": "change",
    "成交量": "volume_lot",
    "成交额": "amount",
    "振幅": "amplitude_pct",
    "最高": "high",
    "最低": "low",
    "今开": "open",
    "昨收": "previous_close",
    "量比": "volume_ratio",
    "换手率": "turnover_pct",
    "市盈率-动态": "pe_dynamic",
    "市净率": "pb",
    "总市值": "market_cap",
    "流通市值": "float_market_cap",
    "涨速": "speed_pct",
    "5分钟涨跌": "change_5m_pct",
    "60日涨跌幅": "change_60d_pct",
    "年初至今涨跌幅": "change_ytd_pct",
}

# 新浪的 ``成交量`` 单位是股，不可沿用东方财富的“手”。量比、换手率、
# 估值和市值等字段在新浪全市场接口中并不存在，必须保留为空值，不能推算或伪造。
SINA_STOCK_COLUMNS = {
    "代码": "code",
    "名称": "name",
    "最新价": "price",
    "涨跌幅": "change_pct",
    "涨跌额": "change",
    "成交量": "volume_shares",
    "成交额": "amount",
    "最高": "high",
    "最低": "low",
    "今开": "open",
    "昨收": "previous_close",
    "买入": "bid",
    "卖出": "ask",
    "时间戳": "source_timestamp",
}

STOCK_SCHEMA = list(
    dict.fromkeys(
        [
            *EASTMONEY_STOCK_COLUMNS.values(),
            *SINA_STOCK_COLUMNS.values(),
            "volume_lot",
            "volume_shares",
            "data_source",
            "data_quality",
        ]
    )
)

PROVIDER_LABELS = {
    "eastmoney": "东方财富增强源",
    "sina": "新浪基础源",
}

BOARD_COLUMNS = {
    "板块名称": "name",
    "板块代码": "code",
    "最新价": "price",
    "涨跌额": "change",
    "涨跌幅": "change_pct",
    "总市值": "market_cap",
    "换手率": "turnover_pct",
    "上涨家数": "up_count",
    "下跌家数": "down_count",
    "领涨股票": "leader_name",
    "领涨股票-涨跌幅": "leader_change_pct",
}

FINANCIAL_COLUMNS = {
    "股票代码": "code",
    "股票简称": "name",
    "每股收益": "eps",
    "营业收入-营业收入": "revenue",
    "营业收入-同比增长": "revenue_yoy_pct",
    "营业收入-季度环比增长": "revenue_qoq_pct",
    "净利润-净利润": "net_profit",
    "净利润-同比增长": "profit_yoy_pct",
    "净利润-季度环比增长": "profit_qoq_pct",
    "每股净资产": "net_asset_per_share",
    "净资产收益率": "roe_pct",
    "每股经营现金流量": "operating_cash_per_share",
    "销售毛利率": "gross_margin_pct",
    "所处行业": "industry",
    "最新公告日期": "announcement_date",
}

VALUATION_COLUMNS = {
    "指数代码": "code",
    "指数名称": "name",
    "发布日期": "date",
    "收盘指数": "close",
    "成交量": "volume_100m_shares",
    "涨跌幅": "change_pct",
    "换手率": "turnover_pct",
    "市盈率": "pe",
    "市净率": "pb",
    "均价": "average_price",
    "成交额占比": "amount_share_pct",
    "流通市值": "float_market_cap_100m",
    "平均流通市值": "average_float_market_cap_100m",
    "股息率": "dividend_yield_pct",
}

MINUTE_COLUMNS = {
    "时间": "datetime",
    "日期时间": "datetime",
    "开盘": "open",
    "收盘": "close",
    "最高": "high",
    "最低": "low",
    "成交量": "volume",
    "成交额": "amount",
    "均价": "average_price",
}


def _normalise(frame: pd.DataFrame, mapping: dict[str, str], numeric: set[str]) -> pd.DataFrame:
    if frame is None or frame.empty:
        return pd.DataFrame(columns=list(mapping.values()))
    result = frame.rename(columns={key: value for key, value in mapping.items() if key in frame.columns}).copy()
    keep = [column for column in mapping.values() if column in result.columns]
    result = result.loc[:, keep]
    if "code" in result:
        result["code"] = result["code"].astype(str).str.extract(r"(\d+)", expand=False).str.zfill(6)
    for column in numeric.intersection(result.columns):
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result["fetched_at"] = now_cn().isoformat()
    return result


def _standardise_stock(
    frame: pd.DataFrame,
    mapping: dict[str, str],
    provider: str,
    quality: str,
) -> pd.DataFrame:
    numeric = set(mapping.values()) - {"code", "name", "source_timestamp"}
    result = _normalise(frame, mapping, numeric)
    for column in STOCK_SCHEMA:
        if column not in result:
            result[column] = pd.NA if column in {"name", "source_timestamp"} else float("nan")
    result["data_source"] = provider
    result["data_quality"] = quality
    ordered = [*STOCK_SCHEMA, "fetched_at"]
    return result.loc[:, [column for column in ordered if column in result.columns]]


@dataclass(frozen=True)
class StockSnapshot:
    frame: pd.DataFrame
    provider: str
    quality: str
    errors: tuple[str, ...] = ()

    @property
    def provider_label(self) -> str:
        return PROVIDER_LABELS.get(self.provider, self.provider)

    @property
    def data_as_of(self) -> str:
        if "fetched_at" in self.frame and self.frame["fetched_at"].notna().any():
            return str(self.frame.loc[self.frame["fetched_at"].notna(), "fetched_at"].iloc[-1])
        return now_cn().isoformat()

    def available(self, column: str) -> bool:
        return bool(
            column in self.frame
            and pd.to_numeric(self.frame[column], errors="coerce").notna().any()
        )

    @property
    def volume_ratio_available(self) -> bool:
        return self.available("volume_ratio")

    @property
    def missing_key_fields(self) -> tuple[str, ...]:
        labels = {
            "volume_ratio": "量比",
            "turnover_pct": "换手率",
            "pe_dynamic": "动态PE",
            "pb": "PB",
            "market_cap": "总市值",
        }
        return tuple(label for column, label in labels.items() if not self.available(column))


@dataclass
class AkShareSource:
    settings: Settings

    def _call(
        self,
        label: str,
        callback: Callable[[], pd.DataFrame],
        attempts: int | None = None,
    ) -> pd.DataFrame:
        attempts = attempts or int(self.settings.get("source.request_retries", 3))
        last_error: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                value = callback()
                if value is None or value.empty:
                    raise DataSourceError(f"{label} 返回空数据")
                return value
            except Exception as exc:  # upstream exceptions change frequently
                last_error = exc
                if attempt < attempts:
                    time.sleep(min(2**attempt, 8))
        raise DataSourceError(f"{label} 获取失败: {last_error}") from last_error

    @staticmethod
    def _ak():
        try:
            import akshare as ak
        except ImportError as exc:
            raise DataSourceError("未安装 AKShare，请重新运行 install.sh") from exc
        return ak

    def stock_spot_eastmoney(self) -> pd.DataFrame:
        ak = self._ak()
        raw = self._call("东方财富A股全市场快照", ak.stock_zh_a_spot_em, attempts=1)
        return _standardise_stock(raw, EASTMONEY_STOCK_COLUMNS, "eastmoney", "enriched")

    def stock_spot_sina(self) -> pd.DataFrame:
        ak = self._ak()
        raw = self._call("新浪A股全市场快照", ak.stock_zh_a_spot, attempts=1)
        return _standardise_stock(raw, SINA_STOCK_COLUMNS, "sina", "basic")

    def stock_spot(self) -> pd.DataFrame:
        """Backward-compatible name for the enriched Eastmoney snapshot."""
        return self.stock_spot_eastmoney()

    def industry_spot(self) -> pd.DataFrame:
        ak = self._ak()
        raw = self._call("行业板块快照", ak.stock_board_industry_name_em, attempts=1)
        numeric = set(BOARD_COLUMNS.values()) - {"code", "name", "leader_name"}
        result = _normalise(raw, BOARD_COLUMNS, numeric)
        result["board_type"] = "industry"
        return result

    def concept_spot(self) -> pd.DataFrame:
        ak = self._ak()
        raw = self._call("概念板块快照", ak.stock_board_concept_name_em, attempts=1)
        numeric = set(BOARD_COLUMNS.values()) - {"code", "name", "leader_name"}
        result = _normalise(raw, BOARD_COLUMNS, numeric)
        result["board_type"] = "concept"
        return result

    def financial_performance(self, report_date: str) -> pd.DataFrame:
        ak = self._ak()
        raw = self._call(
            f"{report_date} 财务业绩报表",
            lambda: ak.stock_yjbb_em(date=report_date),
            attempts=1,
        )
        numeric = set(FINANCIAL_COLUMNS.values()) - {
            "code",
            "name",
            "industry",
            "announcement_date",
        }
        result = _normalise(raw, FINANCIAL_COLUMNS, numeric)
        result["report_date"] = report_date
        return result

    def sw_industry_valuation(
        self, start_date: str | None = None, end_date: str | None = None
    ) -> pd.DataFrame:
        ak = self._ak()
        end = end_date or date.today().strftime("%Y%m%d")
        start = start_date or (date.today() - timedelta(days=550)).strftime("%Y%m%d")
        raw = self._call(
            "申万一级行业估值",
            lambda: ak.index_analysis_daily_sw(
                symbol="一级行业", start_date=start, end_date=end
            ),
            attempts=1,
        )
        numeric = set(VALUATION_COLUMNS.values()) - {"code", "name", "date"}
        result = _normalise(raw, VALUATION_COLUMNS, numeric)
        if "date" in result:
            result["date"] = pd.to_datetime(result["date"], errors="coerce")
        return result

    def stock_minute(self, code: str, period: str = "1") -> pd.DataFrame:
        ak = self._ak()
        raw = self._call(
            f"{code} {period}分钟行情",
            lambda: ak.stock_zh_a_hist_min_em(symbol=str(code).zfill(6), period=str(period), adjust=""),
            attempts=1,
        )
        numeric = {"open", "close", "high", "low", "volume", "amount", "average_price"}
        result = _normalise(raw, MINUTE_COLUMNS, numeric)
        if "datetime" not in result.columns:
            raise DataSourceError(f"{code} 分钟数据缺少时间字段")
        result["datetime"] = pd.to_datetime(result["datetime"], errors="coerce")
        result = result.dropna(subset=["datetime"]).sort_values("datetime")
        result["code"] = str(code).zfill(6)
        return result


@dataclass
class TushareMinuteSource:
    settings: Settings

    def _client(self):
        token = os.getenv("TUSHARE_TOKEN", "").strip()
        if not token:
            raise DataSourceError("minute_provider=tushare，但没有设置 TUSHARE_TOKEN")
        try:
            import tushare as ts
        except ImportError as exc:
            raise DataSourceError("未安装 Tushare，请重新运行 install.sh") from exc
        return ts.pro_api(token)

    @staticmethod
    def _ts_code(code: str) -> str:
        code = str(code).zfill(6)
        return f"{code}.SH" if code.startswith(("5", "6", "9")) else f"{code}.SZ"

    def stock_minute(self, code: str, period: str = "1") -> pd.DataFrame:
        if period not in {"1", "5", "15", "30", "60"}:
            raise DataSourceError("Tushare 原生分钟周期仅支持 1/5/15/30/60；其他周期由 1 分钟合成")
        client = self._client()
        try:
            raw = client.stk_mins(ts_code=self._ts_code(code), freq=f"{period}min")
        except Exception as exc:
            raise DataSourceError(f"Tushare 分钟数据失败: {exc}") from exc
        if raw is None or raw.empty:
            raise DataSourceError(f"Tushare 返回空分钟数据: {code}")
        raw = raw.rename(
            columns={
                "trade_time": "datetime",
                "vol": "volume",
                "trade_date": "date",
            }
        )
        for column in ("open", "close", "high", "low", "volume", "amount"):
            if column in raw:
                raw[column] = pd.to_numeric(raw[column], errors="coerce")
        raw["datetime"] = pd.to_datetime(raw["datetime"], errors="coerce")
        raw["code"] = str(code).zfill(6)
        raw["fetched_at"] = now_cn().isoformat()
        return raw.sort_values("datetime")


@dataclass
class SourceRouter:
    settings: Settings
    _retry_after: dict[str, float] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.akshare = AkShareSource(self.settings)

    def _cooldown_seconds(self, provider: str) -> int:
        default = 1800 if provider == "eastmoney" else 300
        return int(self.settings.get(f"source.{provider}_cooldown_seconds", default))

    def _on_cooldown(self, provider: str) -> bool:
        return time.monotonic() < self._retry_after.get(provider, 0.0)

    def _mark_failure(self, provider: str) -> None:
        self._retry_after[provider] = time.monotonic() + self._cooldown_seconds(provider)

    def stock_snapshot(self) -> StockSnapshot:
        providers = self.settings.get("source.stock_provider_order", ["eastmoney", "sina"])
        if isinstance(providers, str):
            providers = [part.strip() for part in providers.split(",") if part.strip()]
        minimum_rows = int(self.settings.get("source.minimum_stock_rows", 4000))
        errors: list[str] = []
        callbacks = {
            "eastmoney": self.akshare.stock_spot_eastmoney,
            "sina": self.akshare.stock_spot_sina,
        }
        qualities = {"eastmoney": "enriched", "sina": "basic"}
        try_enrichment = bool(
            self.settings.get("source.try_enrichment_after_basic", False)
        )
        basic_snapshot: StockSnapshot | None = None
        for provider_value in providers:
            provider = str(provider_value).strip().lower()
            callback = callbacks.get(provider)
            if callback is None:
                errors.append(f"未知股票快照源：{provider}")
                continue
            if self._on_cooldown(provider):
                errors.append(f"{PROVIDER_LABELS[provider]}处于失败冷却期")
                continue
            try:
                frame = callback()
                if len(frame) < minimum_rows:
                    raise DataSourceError(
                        f"仅返回 {len(frame)} 行，低于全市场完整性下限 {minimum_rows} 行"
                    )
                candidate = StockSnapshot(
                    frame=frame,
                    provider=provider,
                    quality=qualities[provider],
                    errors=tuple(errors),
                )
                if candidate.quality == "basic" and try_enrichment:
                    basic_snapshot = candidate
                    continue
                return candidate
            except Exception as exc:
                self._mark_failure(provider)
                errors.append(f"{PROVIDER_LABELS[provider]}：{exc}")
        if basic_snapshot is not None:
            return StockSnapshot(
                frame=basic_snapshot.frame,
                provider=basic_snapshot.provider,
                quality=basic_snapshot.quality,
                errors=tuple(errors),
            )
        detail = "；".join(errors) if errors else "没有配置可用的股票快照源"
        raise DataSourceError(f"所有A股全市场快照源均失败：{detail}")

    def _eastmoney_call(self, label: str, callback: Callable[[], pd.DataFrame]) -> pd.DataFrame:
        if self._on_cooldown("eastmoney"):
            raise DataSourceError(f"{label}跳过：东方财富增强源处于失败冷却期")
        try:
            return callback()
        except Exception:
            self._mark_failure("eastmoney")
            raise

    def industry(self) -> pd.DataFrame:
        return self._eastmoney_call("行业板块", self.akshare.industry_spot)

    def concept(self) -> pd.DataFrame:
        return self._eastmoney_call("概念板块", self.akshare.concept_spot)

    def financial_performance(self, report_date: str) -> pd.DataFrame:
        return self._eastmoney_call(
            f"{report_date}财报", lambda: self.akshare.financial_performance(report_date)
        )

    def valuation(self) -> pd.DataFrame:
        return self._eastmoney_call("申万行业估值", self.akshare.sw_industry_valuation)

    def minute(self, code: str, period: str = "1") -> pd.DataFrame:
        provider = str(self.settings.get("source.minute_provider", "akshare")).lower()
        if provider == "tushare":
            return TushareMinuteSource(self.settings).stock_minute(code, period)
        return self._eastmoney_call(f"{code}分钟行情", lambda: self.akshare.stock_minute(code, period))
