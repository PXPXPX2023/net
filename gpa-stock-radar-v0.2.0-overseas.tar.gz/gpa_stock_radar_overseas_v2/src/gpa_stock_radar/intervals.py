from __future__ import annotations

from dataclasses import dataclass
from datetime import time

import numpy as np
import pandas as pd


SUPPORTED_PERIODS = (1, 2, 5, 10, 12, 15, 17, 20, 30, 40, 50, 60, 120, 180, 240)


@dataclass(frozen=True)
class PeriodExplanation:
    minutes: int
    bars_per_day: int
    has_structural_partial: bool
    description: str


def period_explanations(periods: list[int] | tuple[int, ...] = SUPPORTED_PERIODS) -> list[PeriodExplanation]:
    values: list[PeriodExplanation] = []
    for period in periods:
        if period <= 120:
            per_session = (120 + period - 1) // period
            remainder = 120 % period
            description = "上午、下午分别起算；不把午休算作交易时间"
            values.append(PeriodExplanation(period, per_session * 2, remainder != 0, description))
        else:
            bars = (240 + period - 1) // period
            remainder = 240 % period
            description = "按全天240个交易分钟编号；午休不计入时长"
            values.append(PeriodExplanation(period, bars, remainder != 0, description))
    return values


def _prepare_minutes(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"datetime", "open", "high", "low", "close", "volume"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"分钟数据缺少字段: {', '.join(sorted(missing))}")
    work = frame.copy()
    work["datetime"] = pd.to_datetime(work["datetime"], errors="coerce")
    work = work.dropna(subset=["datetime"]).sort_values("datetime")
    local_time = work["datetime"].dt.time
    morning = (local_time >= time(9, 30)) & (local_time < time(11, 30))
    afternoon = (local_time >= time(13, 0)) & (local_time < time(15, 0))
    work = work.loc[morning | afternoon].copy()
    local_time = work["datetime"].dt.time
    work["session"] = np.where(local_time < time(12, 0), "AM", "PM")
    minute_of_day = work["datetime"].dt.hour * 60 + work["datetime"].dt.minute
    work["session_offset"] = np.where(
        work["session"].eq("AM"), minute_of_day - (9 * 60 + 30), minute_of_day - (13 * 60)
    )
    work["trading_offset"] = np.where(
        work["session"].eq("AM"), work["session_offset"], 120 + work["session_offset"]
    )
    work["trade_date"] = work["datetime"].dt.date
    return work


def resample_a_share_minutes(
    frame: pd.DataFrame,
    period: int,
    partial_policy: str = "keep_marked",
) -> pd.DataFrame:
    if period not in SUPPORTED_PERIODS:
        raise ValueError(f"不支持 {period} 分钟；可选: {SUPPORTED_PERIODS}")
    work = _prepare_minutes(frame)
    if work.empty:
        return pd.DataFrame()
    if period <= 120:
        work["bucket"] = (work["session_offset"] // period).astype(int)
        group_keys = ["trade_date", "session", "bucket"]
        work["expected_minutes"] = period
        tail_size = 120 % period
        if tail_size:
            last_bucket = 120 // period
            work.loc[work["bucket"].eq(last_bucket), "expected_minutes"] = tail_size
    else:
        work["bucket"] = (work["trading_offset"] // period).astype(int)
        group_keys = ["trade_date", "bucket"]
        work["expected_minutes"] = period
        tail_size = 240 % period
        if tail_size:
            last_bucket = 240 // period
            work.loc[work["bucket"].eq(last_bucket), "expected_minutes"] = tail_size

    aggregations: dict[str, tuple[str, str]] = {
        "datetime": ("datetime", "last"),
        "open": ("open", "first"),
        "high": ("high", "max"),
        "low": ("low", "min"),
        "close": ("close", "last"),
        "volume": ("volume", "sum"),
        "actual_minutes": ("datetime", "count"),
        "expected_minutes": ("expected_minutes", "first"),
    }
    if "amount" in work:
        aggregations["amount"] = ("amount", "sum")
    result = work.groupby(group_keys, sort=True, observed=True).agg(**aggregations).reset_index()
    result["period_minutes"] = period
    result["is_partial"] = result["actual_minutes"] < result["expected_minutes"]
    result["is_structural_partial"] = result["expected_minutes"] < period
    if partial_policy == "drop":
        result = result.loc[~result["is_partial"]].copy()
    elif partial_policy != "keep_marked":
        raise ValueError("partial_policy 只能是 keep_marked 或 drop")
    return result


def add_basic_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    result = frame.copy()
    close = pd.to_numeric(result["close"], errors="coerce")
    volume = pd.to_numeric(result["volume"], errors="coerce")
    result["return_pct"] = close.pct_change() * 100
    result["ma5"] = close.rolling(5, min_periods=1).mean()
    result["ma10"] = close.rolling(10, min_periods=1).mean()
    result["volume_ma5"] = volume.rolling(5, min_periods=1).mean()
    result["bar_volume_ratio"] = volume / result["volume_ma5"].replace(0, np.nan)
    result["trend"] = np.select(
        [close > result["ma5"], close < result["ma5"]],
        ["好/偏强", "坏/偏弱"],
        default="中性",
    )
    return result
