"""GPA A-share stock radar."""

__version__ = "0.2.0"
