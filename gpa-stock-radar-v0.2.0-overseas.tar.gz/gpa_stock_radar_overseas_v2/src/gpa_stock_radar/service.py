from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

from .analysis import analyse_boards, analyse_stocks, market_summary, screen_volume_ratio, valuation_percentiles
from .config import Settings
from .financials import rank_industry_leaders, report_dates
from .intervals import add_basic_indicators, resample_a_share_minutes
from .reporting import ExcelReport, plot_board_strength, plot_live_overview, plot_valuation_percentiles, plot_volume_candidates
from .sources import DataSourceError, SourceRouter
from .storage import RadarStorage
from .util import is_trading_session, now_cn


LOGGER = logging.getLogger("gpa")


@dataclass
class RadarService:
    settings: Settings

    def __post_init__(self) -> None:
        self.storage = RadarStorage(self.settings)
        self.sources = SourceRouter(self.settings)
        self._last_stock_quality = "unknown"

    @staticmethod
    def _health(status: str, message: str = "", **details: object) -> dict[str, object]:
        return {
            "status": status,
            "message": message,
            "updated_at": now_cn().isoformat(),
            **details,
        }

    def _cached_market_result(
        self,
        error: Exception,
        health: dict[str, dict[str, object]],
    ) -> dict:
        stocks = self.storage.read_table("stock_latest")
        if stocks.empty:
            health["stock_spot"] = self._health("error", str(error))
            self.storage.write_health(health)
            raise DataSourceError(
                f"实时源全部失败且尚无本地缓存。{error}。"
                "稍后重试；程序不会用缺失值伪造量比候选。"
            ) from error

        snapshot = self.storage.read_snapshot()
        data_as_of = snapshot.get("data_as_of") or snapshot.get("updated_at")
        health["stock_spot"] = self._health(
            "cache",
            f"实时源失败，保留本地旧快照（数据时间 {data_as_of or '未知'}）：{error}",
            provider="cache",
            quality="stale",
            data_as_of=data_as_of,
            rows=len(stocks),
        )
        ratio_available = (
            "volume_ratio" in stocks
            and pd.to_numeric(stocks["volume_ratio"], errors="coerce").notna().any()
        )
        health["volume_ratio"] = self._health(
            "stale" if ratio_available else "unavailable",
            "缓存中有量比，但已过期，不作为实时预警"
            if ratio_available
            else "缓存没有真实量比；筛选未执行，不代表候选为0只",
            available=bool(ratio_available),
        )
        health["mode"] = self._health("degraded", "缓存降级；未刷新报告文件时间")
        self.storage.update_health(health)
        self.storage.write_health(health)
        self._last_stock_quality = "cache"
        summary = snapshot.get("summary") or market_summary(stocks)
        return {
            "summary": summary,
            "candidate_count": None,
            "cached_candidate_count_hidden": len(snapshot.get("volume_candidates", [])),
            "industry_count": len(snapshot.get("industries", [])),
            "concept_count": len(snapshot.get("concepts", [])),
            "cached": True,
            "health": health,
        }

    def collect_once(self, generate_outputs: bool = True) -> dict:
        previous_snapshot = self.storage.read_snapshot()
        health: dict[str, dict[str, object]] = dict(previous_snapshot.get("health", {}))
        try:
            stock_snapshot = self.sources.stock_snapshot()
        except Exception as exc:
            return self._cached_market_result(exc, health)

        stocks = analyse_stocks(stock_snapshot.frame, self.settings)
        self._last_stock_quality = stock_snapshot.quality
        missing = "、".join(stock_snapshot.missing_key_fields) or "无"
        fallback_detail = ""
        if stock_snapshot.errors:
            fallback_detail = f"；已降级，前序错误：{'｜'.join(stock_snapshot.errors)[:500]}"
        health["stock_spot"] = self._health(
            "ok" if stock_snapshot.quality == "enriched" else "basic",
            f"{stock_snapshot.provider_label}；{len(stocks)}只；缺少关键字段：{missing}{fallback_detail}",
            provider=stock_snapshot.provider,
            quality=stock_snapshot.quality,
            data_as_of=stock_snapshot.data_as_of,
            rows=len(stocks),
            missing_fields=list(stock_snapshot.missing_key_fields),
        )
        health["volume_ratio"] = self._health(
            "ok" if stock_snapshot.volume_ratio_available else "unavailable",
            f"真实量比可用，执行量比 ≥ {self.settings.threshold:.1f} 筛选"
            if stock_snapshot.volume_ratio_available
            else "当前基础源不含真实量比；本轮筛选未执行，不代表候选为0只",
            available=stock_snapshot.volume_ratio_available,
            threshold=self.settings.threshold,
        )

        previous_industries = self.storage.read_table("industry_latest")
        previous_concepts = self.storage.read_table("concept_latest")
        try:
            industries = analyse_boards(self.sources.industry(), self.settings)
            health["industry_spot"] = self._health("ok", f"{len(industries)}个")
        except Exception as exc:
            industries = previous_industries
            health["industry_spot"] = self._health(
                "fallback" if not industries.empty else "unavailable",
                f"{'使用旧板块数据' if not industries.empty else '没有可用板块数据'}：{exc}",
            )
        try:
            concepts = analyse_boards(self.sources.concept(), self.settings)
            health["concept_spot"] = self._health("ok", f"{len(concepts)}个")
        except Exception as exc:
            concepts = previous_concepts
            health["concept_spot"] = self._health(
                "fallback" if not concepts.empty else "unavailable",
                f"{'使用旧板块数据' if not concepts.empty else '没有可用板块数据'}：{exc}",
            )

        candidates = screen_volume_ratio(stocks, self.settings)
        summary = market_summary(stocks)
        summary.update(
            {
                "data_source": stock_snapshot.provider,
                "data_source_name": stock_snapshot.provider_label,
                "data_quality": stock_snapshot.quality,
                "data_as_of": stock_snapshot.data_as_of,
                "volume_ratio_available": stock_snapshot.volume_ratio_available,
                "missing_key_fields": missing,
                "deployment_profile": self.settings.get(
                    "app.deployment_profile", "overseas"
                ),
            }
        )
        health["mode"] = self._health("near_realtime", "免费轮询接口；非Level-2")
        self.storage.save_market(stocks, candidates, industries, concepts, summary, health)
        minute_health = self.collect_priority_minutes(candidates)
        health.update(minute_health)
        self.storage.update_health(health)
        if generate_outputs:
            self.write_live_outputs(summary, candidates, industries, concepts, health)
        return {
            "summary": summary,
            "candidate_count": (
                len(candidates) if stock_snapshot.volume_ratio_available else None
            ),
            "industry_count": len(industries),
            "concept_count": len(concepts),
            "cached": False,
            "health": health,
        }

    def _watchlist_codes(self) -> list[str]:
        watchlist = self.settings.config_path.parent / "watchlist.csv"
        if not watchlist.exists():
            package = Path(__file__).resolve().parents[2] / "config" / "watchlist.csv"
            watchlist = package
        try:
            frame = pd.read_csv(watchlist, dtype=str)
        except Exception:
            return []
        column = "代码" if "代码" in frame else "code" if "code" in frame else None
        return frame[column].dropna().astype(str).str.zfill(6).tolist() if column else []

    def collect_priority_minutes(self, candidates: pd.DataFrame) -> dict[str, dict[str, object]]:
        limit = int(self.settings.get("source.minute_fetch_limit_per_cycle", 20))
        codes = self._watchlist_codes()
        if "code" in candidates:
            codes.extend(candidates["code"].astype(str).tolist())
        codes = list(dict.fromkeys(codes))[:limit]
        successes = 0
        failures: list[str] = []
        for code in codes:
            try:
                minute = self.sources.minute(code, "1")
                self.storage.save_minute(code, minute)
                successes += 1
            except Exception as exc:
                failures.append(f"{code}:{exc}")
        status = "ok" if not failures else "partial" if successes else "error"
        message = f"成功{successes}，失败{len(failures)}"
        if failures:
            message += "；" + "｜".join(failures[:3])
        return {"priority_minutes": self._health(status, message)}

    def multi_period_summary(self, codes: list[str] | None = None) -> pd.DataFrame:
        codes = codes or self._watchlist_codes()
        rows: list[dict[str, object]] = []
        periods = self.settings.periods
        policy = str(self.settings.get("market.partial_bar_policy", "keep_marked"))
        for code in codes:
            minute = self.storage.load_minute(code)
            if minute.empty:
                continue
            row: dict[str, object] = {"code": code}
            good = 0
            bad = 0
            for period in periods:
                bars = add_basic_indicators(resample_a_share_minutes(minute, period, policy))
                if bars.empty:
                    row[f"{period}m"] = "无数据"
                    continue
                latest = bars.iloc[-1]
                trend = str(latest.get("trend", "中性"))
                if bool(latest.get("is_partial", False)) or bool(latest.get("is_structural_partial", False)):
                    trend += "*"
                row[f"{period}m"] = trend
                good += trend.startswith("好")
                bad += trend.startswith("坏")
            row["good_periods"] = good
            row["bad_periods"] = bad
            row["signal"] = "好/多周期偏强" if good >= max(3, bad * 2) else "坏/多周期偏弱" if bad >= max(3, good * 2) else "中性/分歧"
            row["note"] = "*表示当前或结构性不满周期K线"
            rows.append(row)
        return pd.DataFrame(rows)

    def write_live_outputs(
        self,
        summary: dict,
        candidates: pd.DataFrame,
        industries: pd.DataFrame,
        concepts: pd.DataFrame,
        health: dict[str, dict[str, object]] | None = None,
    ) -> list[Path]:
        latest = self.settings.report_dir / "latest"
        volume_message = str((health or {}).get("volume_ratio", {}).get("message", ""))
        outputs = [
            plot_volume_candidates(
                candidates,
                latest / "量比不小于4.9_实时名单.jpg",
                self.settings.threshold,
                volume_message,
            ),
            plot_live_overview(
                summary,
                candidates,
                industries,
                concepts,
                latest / "A股实时总览.jpg",
                self.settings.threshold,
                volume_message,
            ),
            ExcelReport(self.settings).write_live(
                latest / "A股实时总览.xlsx",
                summary,
                candidates,
                industries,
                concepts,
                health,
            ),
        ]
        if not industries.empty:
            outputs.append(plot_board_strength(industries, latest / "行业实时强弱.jpg", "A股行业板块实时强弱"))
        if not concepts.empty:
            outputs.append(plot_board_strength(concepts, latest / "概念实时强弱.jpg", "A股概念板块实时强弱"))
        return outputs

    def finance_once(self, periods: list[str] | None = None) -> dict[str, object]:
        market = self.storage.read_table("stock_latest")
        periods = periods or report_dates(count=int(self.settings.get("financial.report_periods_to_keep", 12)))
        collected: list[pd.DataFrame] = []
        errors: dict[str, str] = {}
        for period_index, report_date in enumerate(periods):
            target = self.settings.data_dir / "financial" / f"performance_{report_date}.csv.gz"
            # Recent four periods are refreshed. Older periods are immutable enough to reuse.
            if period_index >= 4 and target.exists():
                try:
                    cached = pd.read_csv(target, dtype={"code": str})
                    cached["code"] = cached["code"].astype(str).str.zfill(6)
                    collected.append(cached)
                    continue
                except Exception:
                    pass
            try:
                frame = self.sources.financial_performance(report_date)
                frame.to_csv(target, index=False, compression="gzip")
                collected.append(frame)
            except Exception as exc:
                errors[report_date] = str(exc)
        if not collected:
            raise DataSourceError(f"未取得任何财报数据: {errors}")
        history = pd.concat(collected, ignore_index=True)
        latest_date = max(history["report_date"].astype(str))
        leader_frames = [
            rank_industry_leaders(group, self.settings, market)
            for _, group in history.groupby("report_date", sort=False)
        ]
        leaders = pd.concat(leader_frames, ignore_index=True) if leader_frames else pd.DataFrame()
        if not leaders.empty:
            leaders = leaders.sort_values(
                ["report_date", "industry", "industry_rank"], ascending=[False, True, True]
            )
        leaders.to_csv(self.settings.data_dir / "financial" / "leaders_latest.csv.gz", index=False, compression="gzip")
        return {"latest_report_date": latest_date, "reports": len(collected), "leader_rows": len(leaders), "errors": errors}

    def daily_report(self, include_valuation: bool = True) -> Path:
        stocks = self.storage.read_table("stock_latest")
        industries = self.storage.read_table("industry_latest")
        concepts = self.storage.read_table("concept_latest")
        if stocks.empty:
            self.collect_once(generate_outputs=False)
            stocks = self.storage.read_table("stock_latest")
            industries = self.storage.read_table("industry_latest")
            concepts = self.storage.read_table("concept_latest")
        snapshot = self.storage.read_snapshot()
        candidates = screen_volume_ratio(stocks, self.settings)
        volume_health = snapshot.get("health", {}).get("volume_ratio", {})
        if isinstance(volume_health, dict) and volume_health.get("status") in {
            "unavailable",
            "stale",
            "error",
        }:
            candidates = candidates.iloc[0:0].copy()
        valuation = pd.DataFrame()
        if include_valuation:
            try:
                valuation_history = self.sources.valuation()
                valuation = valuation_percentiles(valuation_history)
                plot_valuation_percentiles(valuation, self.settings.report_dir / "latest" / "行业估值分位.jpg")
            except Exception as exc:
                LOGGER.warning("行业估值获取失败: %s", exc)
        leader_path = self.settings.data_dir / "financial" / "leaders_latest.csv.gz"
        leaders = pd.read_csv(leader_path, dtype={"code": str}) if leader_path.exists() else pd.DataFrame()
        multi = self.multi_period_summary(list(dict.fromkeys(self._watchlist_codes() + candidates.get("code", pd.Series(dtype=str)).astype(str).head(20).tolist())))
        report_summary = market_summary(stocks)
        for key in (
            "data_source",
            "data_source_name",
            "data_quality",
            "data_as_of",
            "volume_ratio_available",
            "missing_key_fields",
            "deployment_profile",
        ):
            if key in snapshot.get("summary", {}):
                report_summary[key] = snapshot["summary"][key]
        date_text = now_cn().strftime("%Y-%m-%d")
        dated = self.settings.report_dir / "daily" / date_text / f"{date_text}_每日盘后完整分析.xlsx"
        ExcelReport(self.settings).write_daily(
            dated, report_summary, stocks, candidates, industries, concepts,
            valuation, leaders, multi, snapshot.get("health", {}),
        )
        latest = self.settings.report_dir / "latest" / "每日盘后完整分析.xlsx"
        latest.parent.mkdir(parents=True, exist_ok=True)
        latest.write_bytes(dated.read_bytes())
        return latest

    def run_forever(self) -> None:
        LOGGER.info("GPA collector started")
        last_live_output = 0.0
        while True:
            started = time.monotonic()
            try:
                trading = is_trading_session()
                live_interval = int(self.settings.get("reports.live_jpg_every_seconds", 300))
                generate = trading and (started - last_live_output >= live_interval)
                self.collect_once(generate_outputs=generate)
                if generate:
                    last_live_output = time.monotonic()
            except Exception:
                LOGGER.exception("采集周期失败")
            if is_trading_session():
                interval = int(self.settings.get("source.stock_poll_seconds", 60))
                if self._last_stock_quality in {"basic", "cache"}:
                    interval = max(
                        interval,
                        int(self.settings.get("source.basic_provider_min_poll_seconds", 300)),
                    )
            else:
                interval = int(self.settings.get("source.closed_poll_seconds", 600))
            time.sleep(max(1, interval - (time.monotonic() - started)))
