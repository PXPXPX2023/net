from __future__ import annotations

import argparse
import json
import logging
import subprocess
import sys
from pathlib import Path

from . import __version__
from .config import load_settings
from .doctor import run_doctor
from .intervals import period_explanations
from .migration import create_backup, restore_backup


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gpa", description="GPA A股实时雷达与盘后复盘")
    parser.add_argument("--config", help="自定义 config.yaml 路径")
    parser.add_argument("--version", action="version", version=f"gpa {__version__}")
    commands = parser.add_subparsers(dest="command")
    commands.add_parser("screen", help="进入 SSH 实时筛选界面（默认命令）")
    commands.add_parser("once", help="立即采集一次并生成实时 JPG")
    commands.add_parser("daily", aliases=["report"], help="生成盘后完整 Excel/JPG")
    finance = commands.add_parser("finance", help="抓取并分析年报/半年报/季报")
    finance.add_argument("--period", action="append", help="指定报告期，如 20260630；可重复")
    doctor = commands.add_parser("doctor", help="检查系统、目录、依赖和数据源")
    doctor.add_argument("--network", action="store_true", help="实际访问一次全市场数据接口")
    commands.add_parser("periods", help="解释全部自定义分钟周期")
    commands.add_parser("profile", help="显示当前海外版/中国境内版配置")
    commands.add_parser("status", help="显示最近采集状态")
    commands.add_parser("files", help="列出最新报告文件")
    backup = commands.add_parser("backup", help="创建可迁移备份")
    mode = backup.add_mutually_exclusive_group()
    mode.add_argument("--core", action="store_true", help="核心备份：配置、数据库、财报和最新报告")
    mode.add_argument("--full", action="store_true", help="完整备份：除历史备份外的全部数据")
    backup.add_argument("--without-secrets", action="store_true", help="不备份 secrets.env")
    backup.add_argument("-o", "--output", type=Path, help="输出 .tar.zst 路径")
    restore = commands.add_parser("restore", help="从迁移备份覆盖式恢复；不会删除现有额外文件")
    restore.add_argument("archive", type=Path)
    restore.add_argument("--no-checksum", action="store_true")
    service = commands.add_parser("service", help="管理 systemd 服务")
    service.add_argument("action", choices=("start", "stop", "restart", "status", "logs"))
    commands.add_parser("daemon", help=argparse.SUPPRESS)
    return parser


def _print_doctor(rows: list[dict[str, object]]) -> int:
    failed = False
    for row in rows:
        if row["ok"]:
            symbol = "!" if row.get("warning") else "✓"
        else:
            symbol = "✗"
            failed = True
        print(f"{symbol} {row['item']}: {row['detail']}")
    return 1 if failed else 0


def _systemd(action: str) -> int:
    if action == "logs":
        command = ["journalctl", "-u", "gpa-collector.service", "-n", "100", "-f"]
    else:
        command = ["systemctl", action, "gpa-collector.service"]
    return subprocess.call(command)


def main(argv: list[str] | None = None) -> None:
    args = _parser().parse_args(argv)
    settings = load_settings(args.config)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    command = args.command
    if command in {None, "screen"}:
        from .tui import run_tui

        run_tui(settings)
        return
    if command == "doctor":
        raise SystemExit(_print_doctor(run_doctor(settings, args.network)))
    if command == "periods":
        for item in period_explanations(settings.periods):
            partial = "有尾部短K线" if item.has_structural_partial else "无结构性短K线"
            print(f"{item.minutes:>3}分钟：约{item.bars_per_day}根/日，{partial}；{item.description}")
        return
    if command == "profile":
        print(
            json.dumps(
                {
                    "version": __version__,
                    "profile": settings.get("app.deployment_profile", "overseas"),
                    "name": settings.get("app.name", "GPA A股雷达"),
                    "stock_provider_order": settings.get(
                        "source.stock_provider_order", ["eastmoney", "sina"]
                    ),
                    "try_enrichment_after_basic": settings.get(
                        "source.try_enrichment_after_basic", False
                    ),
                    "stock_poll_seconds": settings.get("source.stock_poll_seconds", 60),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return
    if command == "files":
        latest = settings.report_dir / "latest"
        for path in sorted(latest.glob("*")):
            if path.is_file():
                print(f"{path.stat().st_size:>12}  {path}")
        return
    if command == "backup":
        mode = "full" if args.full else "core"
        archive, checksum = create_backup(settings, mode, args.output, not args.without_secrets)
        print(archive)
        print(checksum)
        return
    if command == "restore":
        manifest = restore_backup(settings, args.archive, not args.no_checksum)
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return
    if command == "service":
        raise SystemExit(_systemd(args.action))

    from .service import RadarService
    from .sources import DataSourceError

    service = RadarService(settings)
    try:
        if command == "once":
            print(json.dumps(service.collect_once(), ensure_ascii=False, indent=2, default=str))
        elif command in {"daily", "report"}:
            print(service.daily_report())
        elif command == "finance":
            print(json.dumps(service.finance_once(args.period), ensure_ascii=False, indent=2, default=str))
        elif command == "status":
            snapshot = service.storage.read_snapshot()
            print(
                json.dumps(
                    snapshot or {"health": service.storage.read_health()},
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
        elif command == "daemon":
            service.run_forever()
        else:
            raise SystemExit(f"未知命令: {command}")
    except DataSourceError as exc:
        print(f"GPA 数据源提示：{exc}", file=sys.stderr)
        raise SystemExit(2) from None
