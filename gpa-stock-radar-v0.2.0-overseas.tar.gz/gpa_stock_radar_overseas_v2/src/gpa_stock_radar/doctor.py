from __future__ import annotations

import importlib
import os
import platform
import sys
import tempfile
from pathlib import Path

from .config import Settings
from .sources import SourceRouter
from .util import now_cn


def _result(name: str, ok: bool, detail: str, warning: bool = False) -> dict[str, object]:
    return {"item": name, "ok": ok, "warning": warning, "detail": detail}


def run_doctor(settings: Settings, network: bool = False) -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    profile = str(settings.get("app.deployment_profile", "overseas"))
    profile_label = "海外版" if profile == "overseas" else "中国境内版" if profile == "china" else profile
    order = settings.get("source.stock_provider_order", [])
    results.append(_result("区域版本", profile in {"overseas", "china"}, f"{profile_label}；行情顺序={order}"))
    results.append(_result("Python", sys.version_info >= (3, 11), platform.python_version()))
    os_release = Path("/etc/os-release")
    release = os_release.read_text(encoding="utf-8", errors="replace") if os_release.exists() else platform.platform()
    debian12 = "ID=debian" in release and ("VERSION_ID=\"12\"" in release or "VERSION_ID=12" in release)
    results.append(_result("操作系统", True, "Debian 12：完全支持，无需更换" if debian12 else platform.platform(), warning=not debian12))
    for module in ("akshare", "pandas", "numpy", "matplotlib", "xlsxwriter", "rich", "yaml", "tushare"):
        try:
            value = importlib.import_module(module)
            version = getattr(value, "__version__", "已安装")
            results.append(_result(f"依赖 {module}", True, str(version)))
        except Exception as exc:
            results.append(_result(f"依赖 {module}", False, str(exc)))
    for label, path in (("数据目录", settings.data_dir), ("报告目录", settings.report_dir), ("日志目录", settings.log_dir)):
        try:
            path.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=path, prefix=".gpa-write-test-", delete=True):
                pass
            results.append(_result(label, True, str(path)))
        except Exception as exc:
            results.append(_result(label, False, f"{path}: {exc}"))
    token = bool(os.getenv("TUSHARE_TOKEN", "").strip())
    provider = str(settings.get("source.minute_provider", "akshare"))
    results.append(_result("分钟数据模式", provider != "tushare" or token, f"provider={provider}；TUSHARE_TOKEN={'已设置' if token else '未设置'}", warning=not token))
    results.append(_result("北京时间", True, now_cn().isoformat()))
    if network:
        try:
            snapshot = SourceRouter(settings).stock_snapshot()
            fallback = f"；前序失败：{'｜'.join(snapshot.errors)[:400]}" if snapshot.errors else ""
            results.append(
                _result(
                    "网络/A股快照",
                    len(snapshot.frame) >= int(settings.get("source.minimum_stock_rows", 4000)),
                    f"{snapshot.provider_label}，取得 {len(snapshot.frame)} 行，质量={snapshot.quality}{fallback}",
                    warning=snapshot.quality != "enriched",
                )
            )
            results.append(
                _result(
                    "网络/量比筛选",
                    True,
                    "真实量比可用，可执行筛选"
                    if snapshot.volume_ratio_available
                    else "当前源不含真实量比；程序会停用筛选并明确标注，不会误报0只",
                    warning=not snapshot.volume_ratio_available,
                )
            )
        except Exception as exc:
            results.append(_result("网络/A股快照", False, str(exc)))
    return results
