from __future__ import annotations

from datetime import datetime, time
from typing import Any

import numpy as np
import pandas as pd

from .config import Settings
from .util import SHANGHAI, now_cn


def _percentile(series: pd.Series, ascending: bool = True) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().sum() <= 1:
        result = pd.Series(np.nan, index=series.index, dtype=float)
        result.loc[numeric.notna()] = 50.0
        return result
    ranked = numeric.rank(pct=True, ascending=ascending) * 100.0
    return ranked


def _signal(score: pd.Series, good_min: float, bad_max: float) -> pd.Series:
    return pd.Series(
        np.select(
            [score >= good_min, score <= bad_max],
            ["好/偏强", "坏/偏弱"],
            default="中性/观察",
        ),
        index=score.index,
    )


def analyse_stocks(frame: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    result = frame.copy()
    for column in ("change_pct", "turnover_pct", "volume_ratio", "amount"):
        if column not in result:
            result[column] = np.nan
    components = (
        ("change_pct", "涨幅", 0.30, pd.to_numeric(result["change_pct"], errors="coerce")),
        ("turnover_pct", "换手", 0.20, pd.to_numeric(result["turnover_pct"], errors="coerce")),
        ("volume_ratio", "量比", 0.25, pd.to_numeric(result["volume_ratio"], errors="coerce")),
        (
            "amount",
            "成交额",
            0.15,
            np.log1p(pd.to_numeric(result["amount"], errors="coerce").clip(lower=0)),
        ),
    )
    weighted = pd.Series(0.0, index=result.index)
    available_weight = pd.Series(0.0, index=result.index)
    basis: list[list[str]] = [[] for _ in range(len(result))]
    for _column, label, weight, numeric in components:
        valid = numeric.notna()
        ranked = _percentile(numeric)
        weighted = weighted.add(ranked.fillna(0) * weight, fill_value=0)
        available_weight = available_weight.add(valid.astype(float) * weight, fill_value=0)
        for position in np.flatnonzero(valid.to_numpy()):
            basis[position].append(label)
    scores = weighted.div(available_weight.replace(0, np.nan)).fillna(50.0)
    result["score"] = scores.round(1)
    coverage = available_weight / sum(component[2] for component in components)
    result["score_confidence"] = np.select(
        [coverage >= 0.80, coverage >= 0.55],
        ["高", "中"],
        default="低",
    )
    result["score_basis"] = ["+".join(items) if items else "无可用评分字段" for items in basis]
    thresholds = settings.scoring.get("signal_thresholds", {})
    result["signal"] = _signal(
        result["score"],
        float(thresholds.get("good_min", 60)),
        float(thresholds.get("bad_max", 40)),
    )
    result["risk"] = ""
    names = result.get("name", pd.Series("", index=result.index)).astype(str)
    result.loc[names.str.contains(r"ST|退", case=False, regex=True), "risk"] = "ST或退市风险"
    result.loc[pd.to_numeric(result.get("price"), errors="coerce").fillna(0) <= 0, "risk"] = "停牌或价格无效"
    def reason(row: pd.Series) -> str:
        def metric(column: str, suffix: str = "") -> str:
            value = pd.to_numeric(pd.Series([row.get(column)]), errors="coerce").iloc[0]
            return "缺失" if pd.isna(value) else f"{float(value):.2f}{suffix}"

        return (
            f"涨幅{metric('change_pct', '%')}｜"
            f"量比{metric('volume_ratio')}｜"
            f"换手{metric('turnover_pct', '%')}｜"
            f"依据{row.get('score_basis', '')}"
        )

    result["reason"] = result.apply(reason, axis=1)
    return result


def screen_volume_ratio(frame: pd.DataFrame, settings: Settings, moment: datetime | None = None) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    result = frame.copy()
    ratio = pd.to_numeric(
        result.get("volume_ratio", pd.Series(np.nan, index=result.index)), errors="coerce"
    )
    price = pd.to_numeric(
        result.get("price", pd.Series(np.nan, index=result.index)), errors="coerce"
    )
    mask = ratio.ge(settings.threshold) & price.gt(0)
    if not bool(settings.get("market.include_st", True)) and "name" in result:
        mask &= ~result["name"].astype(str).str.contains(r"ST|退", case=False, regex=True)
    minimum_amount = float(settings.get("market.minimum_amount_yuan", 0))
    if minimum_amount > 0 and "amount" in result:
        mask &= pd.to_numeric(result["amount"], errors="coerce").ge(minimum_amount)
    result = result.loc[mask].copy()
    result = result.sort_values(["volume_ratio", "amount"], ascending=[False, False])
    limit = int(settings.get("market.candidate_limit", 200))
    result = result.head(limit)
    current = (moment or now_cn()).astimezone(SHANGHAI).time().replace(tzinfo=None)
    cutoff = time.fromisoformat(str(settings.get("market.early_open_noise_until", "09:35")))
    result["opening_noise"] = current < cutoff
    result["threshold"] = settings.threshold
    return result


def analyse_boards(frame: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    if frame.empty:
        return frame.copy()
    result = frame.copy()
    for column in ("change_pct", "turnover_pct", "up_count", "down_count", "leader_change_pct"):
        if column not in result:
            result[column] = np.nan
    up = pd.to_numeric(result["up_count"], errors="coerce")
    down = pd.to_numeric(result["down_count"], errors="coerce")
    result["breadth_pct"] = (up / (up + down).replace(0, np.nan) * 100).fillna(50)
    result["score"] = (
        _percentile(result["change_pct"]) * 0.45
        + _percentile(result["turnover_pct"]) * 0.15
        + result["breadth_pct"].clip(0, 100) * 0.25
        + _percentile(result["leader_change_pct"]) * 0.15
    ).round(1)
    thresholds = settings.scoring.get("signal_thresholds", {})
    result["signal"] = _signal(
        result["score"],
        float(thresholds.get("good_min", 60)),
        float(thresholds.get("bad_max", 40)),
    )
    result["reason"] = (
        "板块涨幅" + result["change_pct"].round(2).astype(str)
        + "%｜上涨占比" + result["breadth_pct"].round(0).astype(str) + "%"
    )
    return result.sort_values("score", ascending=False)


def market_summary(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {"count": 0}
    change = pd.to_numeric(frame.get("change_pct"), errors="coerce")
    amount = pd.to_numeric(frame.get("amount"), errors="coerce")
    valid = change.notna()
    return {
        "count": int(valid.sum()),
        "up": int((change > 0).sum()),
        "down": int((change < 0).sum()),
        "flat": int((change == 0).sum()),
        "limit_up_approx": int((change >= 9.8).sum()),
        "limit_down_approx": int((change <= -9.8).sum()),
        "median_change_pct": round(float(change.median()), 3) if valid.any() else None,
        "total_amount_yi": round(float(amount.sum()) / 100_000_000, 2),
        "breadth_pct": round(float((change > 0).sum() / max(valid.sum(), 1) * 100), 2),
        "updated_at": now_cn().isoformat(),
    }


def valuation_percentiles(history: pd.DataFrame) -> pd.DataFrame:
    required = {"code", "name", "date", "pe"}
    if history.empty or not required.issubset(history.columns):
        return pd.DataFrame()
    work = history.dropna(subset=["code", "date", "pe"]).sort_values("date").copy()
    rows: list[dict[str, Any]] = []
    for code, group in work.groupby("code", sort=False):
        positive = group.loc[pd.to_numeric(group["pe"], errors="coerce") > 0].copy()
        if positive.empty:
            continue
        latest = positive.iloc[-1]
        current = float(latest["pe"])
        percentile = float((positive["pe"] <= current).mean() * 100)
        status = "好/低估" if percentile <= 30 else "坏/高估" if percentile >= 70 else "中性"
        rows.append(
            {
                "code": code,
                "name": latest["name"],
                "date": latest["date"],
                "pe": current,
                "pb": latest.get("pb"),
                "change_pct": latest.get("change_pct"),
                "pe_percentile": round(percentile, 1),
                "history_points": int(len(positive)),
                "signal": status,
                "note": "周期行业需结合盈利周期，低PE不等于低风险",
            }
        )
    return pd.DataFrame(rows).sort_values("pe_percentile", ascending=False)
