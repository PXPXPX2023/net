from __future__ import annotations

import math
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import Settings
from .util import now_cn


BACKGROUND = "#081624"
PANEL = "#0D2236"
GRID = "#244057"
BLUE = "#33A7FF"
WHITE = "#FFFFFF"
GREY = "#A9B7C6"
ORANGE = "#FFB454"


COLUMN_LABELS = {
    "code": "代码",
    "name": "名称",
    "price": "最新价",
    "change_pct": "涨跌幅(%)",
    "volume_ratio": "量比",
    "turnover_pct": "换手率(%)",
    "amount": "成交额(元)",
    "volume_lot": "成交量(手)",
    "volume_shares": "成交量(股)",
    "market_cap": "总市值(元)",
    "pe_dynamic": "动态PE",
    "pb": "PB",
    "score": "评分",
    "signal": "好坏判定",
    "risk": "风险标签",
    "reason": "判定原因",
    "opening_noise": "开盘噪声",
    "threshold": "量比阈值",
    "breadth_pct": "上涨占比(%)",
    "up_count": "上涨家数",
    "down_count": "下跌家数",
    "leader_name": "领涨股",
    "leader_change_pct": "领涨股涨幅(%)",
    "pe": "市盈率",
    "pe_percentile": "PE历史分位(%)",
    "history_points": "历史样本数",
    "note": "说明",
    "industry": "行业",
    "industry_rank": "行业排名",
    "leader_score": "龙头总分",
    "leader_type": "龙头类型",
    "score_confidence": "置信度",
    "score_basis": "评分依据",
    "data_source": "数据源",
    "data_quality": "数据质量",
    "source_timestamp": "源时间戳",
    "report_date": "报告期",
    "report_kind": "报告类型",
    "revenue": "营业收入",
    "revenue_yoy_pct": "营收同比(%)",
    "revenue_qoq_pct": "营收环比(%)",
    "net_profit": "净利润",
    "profit_yoy_pct": "净利同比(%)",
    "profit_qoq_pct": "净利环比(%)",
    "roe_pct": "ROE(%)",
    "gross_margin_pct": "毛利率(%)",
    "operating_cash_per_share": "每股经营现金流",
    "fetched_at": "数据时间",
    "status": "状态",
    "message": "说明",
    "updated_at": "更新时间",
    "provider": "提供方",
    "quality": "质量等级",
    "available": "是否可用",
    "missing_fields": "缺失字段",
}


def _volume_note(health: dict[str, Any] | None, threshold: float) -> str:
    item = (health or {}).get("volume_ratio", {})
    if isinstance(item, dict) and item.get("status") in {"unavailable", "stale", "error"}:
        return str(item.get("message") or "量比字段不可用；筛选未执行")
    return f"筛选条件为量比不小于 {threshold:.1f}；等于阈值也会入选"


def _configure_fonts() -> None:
    plt.rcParams["font.sans-serif"] = [
        "Noto Sans CJK SC",
        "Noto Sans SC Thin",
        "Source Han Sans CN",
        "WenQuanYi Zen Hei",
        "Arial Unicode MS",
        "DejaVu Sans",
    ]
    plt.rcParams["axes.unicode_minus"] = False


def _style_for_signal(signal: Any) -> str:
    text = str(signal)
    if text.startswith("好"):
        return BLUE
    if text.startswith("坏"):
        return WHITE
    if "异常" in text or "过期" in text or "低" == text:
        return ORANGE
    return GREY


class ExcelReport:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.colors = {
            "positive": settings.get("reports.positive_text_color", BLUE),
            "negative": settings.get("reports.negative_text_color", WHITE),
            "neutral": settings.get("reports.neutral_text_color", GREY),
            "warning": settings.get("reports.warning_text_color", ORANGE),
        }

    def _formats(self, workbook):
        base = {"bg_color": BACKGROUND, "font_color": WHITE, "border": 1, "border_color": GRID}
        return {
            "title": workbook.add_format(
                {"bold": True, "font_size": 16, "font_color": WHITE, "bg_color": BACKGROUND, "align": "left", "valign": "vcenter"}
            ),
            "subtitle": workbook.add_format(
                {"font_size": 9, "font_color": GREY, "bg_color": BACKGROUND, "align": "left"}
            ),
            "header": workbook.add_format(
                {"bold": True, "font_color": WHITE, "bg_color": "#163B5C", "border": 1, "border_color": GRID, "align": "center", "valign": "vcenter", "text_wrap": True}
            ),
            "text": workbook.add_format({**base, "align": "left"}),
            "number": workbook.add_format({**base, "num_format": "0.00", "align": "right"}),
            "integer": workbook.add_format({**base, "num_format": "0", "align": "right"}),
            "good": workbook.add_format({**base, "font_color": self.colors["positive"]}),
            "bad": workbook.add_format({**base, "font_color": self.colors["negative"]}),
            "neutral": workbook.add_format({**base, "font_color": self.colors["neutral"]}),
            "warning": workbook.add_format({**base, "font_color": self.colors["warning"]}),
            "percent": workbook.add_format({**base, "num_format": "0.00", "align": "right"}),
            "money": workbook.add_format({**base, "num_format": "#,##0", "align": "right"}),
            "link": workbook.add_format({**base, "font_color": self.colors["positive"], "underline": True}),
        }

    def _write_frame(self, workbook, sheet_name: str, frame: pd.DataFrame, title: str, note: str = ""):
        worksheet = workbook.add_worksheet(sheet_name[:31])
        worksheet.hide_gridlines(2)
        worksheet.set_tab_color(BLUE)
        formats = self._formats(workbook)
        columns = list(frame.columns)
        span = max(len(columns), 4)
        worksheet.merge_range(0, 0, 0, span - 1, title, formats["title"])
        worksheet.merge_range(
            1, 0, 1, span - 1,
            f"生成时间（北京时间）：{now_cn():%Y-%m-%d %H:%M:%S}　{note}",
            formats["subtitle"],
        )
        header_row = 3
        for column_index, column in enumerate(columns):
            worksheet.write(header_row, column_index, COLUMN_LABELS.get(column, column), formats["header"])

        for row_offset, (_, row) in enumerate(frame.iterrows(), start=1):
            excel_row = header_row + row_offset
            signal = row.get("signal", row.get("trend", ""))
            risk = str(row.get("risk", ""))
            signal_format = formats["good"] if str(signal).startswith("好") else formats["bad"] if str(signal).startswith("坏") else formats["neutral"]
            if risk or str(row.get("score_confidence", "")) == "低":
                signal_format = formats["warning"]
            for column_index, column in enumerate(columns):
                value = row[column]
                if isinstance(value, (list, tuple, set)):
                    worksheet.write(excel_row, column_index, "、".join(map(str, value)), signal_format)
                elif isinstance(value, dict):
                    worksheet.write(excel_row, column_index, str(value), signal_format)
                elif pd.isna(value):
                    worksheet.write_blank(excel_row, column_index, None, formats["neutral"])
                elif isinstance(value, (bool, np.bool_)):
                    worksheet.write(excel_row, column_index, "是" if value else "否", signal_format)
                elif isinstance(value, (int, np.integer)):
                    worksheet.write_number(excel_row, column_index, int(value), signal_format)
                elif isinstance(value, (float, np.floating)) and math.isfinite(float(value)):
                    worksheet.write_number(excel_row, column_index, float(value), signal_format)
                elif isinstance(value, (datetime, pd.Timestamp)):
                    worksheet.write(excel_row, column_index, value.isoformat(), signal_format)
                else:
                    worksheet.write(excel_row, column_index, str(value), signal_format)

        if columns:
            last_row = header_row + max(len(frame), 1)
            worksheet.autofilter(header_row, 0, last_row, len(columns) - 1)
            worksheet.freeze_panes(header_row + 1, min(2, len(columns)))
        worksheet.set_row(0, 28)
        for index, column in enumerate(columns):
            label = COLUMN_LABELS.get(column, column)
            sample = [str(value) for value in frame[column].head(100).dropna().tolist()]
            width = min(max([len(label) * 1.7, *[len(value) * 1.2 for value in sample]]), 42)
            if column in {"reason", "risk", "note"}:
                width = min(max(width, 24), 48)
            worksheet.set_column(index, index, width, formats["text"])
        worksheet.set_default_row(19)
        return worksheet, formats, header_row

    def write_daily(
        self,
        target: Path,
        summary: dict[str, Any],
        stocks: pd.DataFrame,
        candidates: pd.DataFrame,
        industries: pd.DataFrame,
        concepts: pd.DataFrame,
        valuations: pd.DataFrame | None = None,
        leaders: pd.DataFrame | None = None,
        multi_period: pd.DataFrame | None = None,
        health: dict[str, Any] | None = None,
    ) -> Path:
        target.parent.mkdir(parents=True, exist_ok=True)
        with pd.ExcelWriter(target, engine="xlsxwriter") as writer:
            workbook = writer.book
            workbook.set_properties(
                {"title": "GPA A股盘后完整分析", "subject": "自动化行情、量比、板块与财报研究", "author": "GPA Stock Radar"}
            )
            summary_rows = pd.DataFrame(
                [{"指标": key, "数值": value} for key, value in summary.items()]
            )
            self._write_frame(workbook, "市场总览", summary_rows, "A股市场总览", "涨停/跌停为统一阈值近似值")
            stock_columns = [column for column in (
                "code", "name", "price", "change_pct", "volume_ratio", "turnover_pct", "amount",
                "volume_lot", "volume_shares",
                "market_cap", "float_market_cap", "pe_dynamic", "pb", "change_5m_pct",
                "change_60d_pct", "change_ytd_pct", "score", "signal", "score_confidence",
                "score_basis", "risk", "reason", "data_source", "data_quality", "fetched_at"
            ) if column in stocks]
            self._write_frame(
                workbook, "全市场快照", stocks[stock_columns], "A股全市场完整快照",
                "用于盘后筛选和复核；停牌、缺失值与风险标签均保留"
            )
            candidate_columns = [column for column in (
                "code", "name", "price", "change_pct", "volume_ratio", "turnover_pct",
                "amount", "market_cap", "pe_dynamic", "pb", "score", "signal",
                "score_confidence", "score_basis", "risk", "reason", "data_source",
                "data_quality", "opening_noise", "fetched_at"
            ) if column in candidates]
            self._write_frame(
                workbook, "量比不小于4.9", candidates[candidate_columns],
                f"量比不小于 {self.settings.threshold:.1f} 的实时候选",
                f"{_volume_note(health, self.settings.threshold)}；不是买卖建议",
            )
            board_columns = [column for column in (
                "code", "name", "change_pct", "turnover_pct", "breadth_pct", "up_count", "down_count", "leader_name", "leader_change_pct", "score", "signal", "reason", "fetched_at"
            ) if column in industries]
            industry_sheet, formats, header_row = self._write_frame(
                workbook, "行业实时强弱", industries[board_columns], "行业板块实时强弱", "按涨幅、换手、上涨占比与领涨股综合评分"
            )
            if len(industries) > 0 and "score" in board_columns and "name" in board_columns:
                chart = workbook.add_chart({"type": "bar"})
                name_col = board_columns.index("name")
                score_col = board_columns.index("score")
                count = min(len(industries), 12)
                chart.add_series({
                    "name": "板块评分",
                    "categories": ["行业实时强弱", header_row + 1, name_col, header_row + count, name_col],
                    "values": ["行业实时强弱", header_row + 1, score_col, header_row + count, score_col],
                    "fill": {"color": BLUE}, "border": {"none": True},
                })
                chart.set_chartarea({"fill": {"color": PANEL}, "border": {"color": GRID}})
                chart.set_plotarea({"fill": {"color": PANEL}, "border": {"none": True}})
                chart.set_title({"name": "行业综合评分 Top 12", "name_font": {"color": WHITE}})
                chart.set_legend({"none": True})
                chart.set_x_axis({"min": 0, "max": 100, "num_font": {"color": GREY}, "line": {"color": GRID}})
                chart.set_y_axis({"num_font": {"color": WHITE}, "line": {"color": GRID}})
                industry_sheet.insert_chart(3, len(board_columns) + 2, chart, {"x_scale": 1.2, "y_scale": 1.15})
            concept_columns = [column for column in board_columns if column in concepts]
            self._write_frame(workbook, "概念实时强弱", concepts[concept_columns], "概念板块实时强弱", "概念重叠较多，不能与行业排名等同")
            if multi_period is not None:
                self._write_frame(workbook, "多周期共振", multi_period, "重点股票多周期共振", "各周期来自同一套1分钟数据，不是独立证据")
            if valuations is not None:
                self._write_frame(workbook, "行业估值分位", valuations, "申万一级行业 PE 历史分位", "低分位显示为好/蓝色；周期行业须结合盈利周期")
            if leaders is not None:
                leader_columns = [column for column in (
                    "industry", "industry_rank", "code", "name", "leader_type", "leader_score", "signal", "score_confidence", "report_date", "report_kind", "revenue", "revenue_yoy_pct", "net_profit", "profit_yoy_pct", "roe_pct", "gross_margin_pct", "operating_cash_per_share", "market_cap", "pe_dynamic", "pb", "risk"
                ) if column in leaders]
                self._write_frame(workbook, "板块财报龙头", leaders[leader_columns], "各行业财报龙头排名", "同行业、同报告期比较；区分规模/成长/质量/现金流/综合龙头")
            health_frame = pd.DataFrame(
                [{"模块": key, **(value if isinstance(value, dict) else {"状态": value})} for key, value in (health or {}).items()]
            )
            self._write_frame(workbook, "数据健康", health_frame, "数据源健康与更新时间", "橙色表示低置信度、过期或接口异常")
            instructions = pd.DataFrame(
                [
                    {"项目": "颜色", "说明": "好/偏强=蓝色；坏/偏弱=白色；中性=灰色；异常/低置信度=橙色。另有文字标签，避免只靠颜色。"},
                    {"项目": "实时性", "说明": "免费模式为轮询近实时，不是交易所授权 Level-2；请查看每张表的数据时间。"},
                    {"项目": "量比", "说明": f"{_volume_note(health, self.settings.threshold)}；早盘波动大，有数据时会保留并标注。"},
                    {"项目": "龙头", "说明": "龙头是规则化研究排名，不代表未来收益；银行、券商、地产、周期行业应使用专用模型复核。"},
                    {"项目": "免责声明", "说明": "本文件仅用于研究、学习与复盘，不构成投资建议或自动交易指令。"},
                ]
            )
            self._write_frame(workbook, "使用说明", instructions, "使用说明与判定口径")
        return target

    def write_live(
        self,
        target: Path,
        summary: dict[str, Any],
        candidates: pd.DataFrame,
        industries: pd.DataFrame,
        concepts: pd.DataFrame,
        health: dict[str, Any] | None = None,
    ) -> Path:
        """Small, frequently overwritten workbook for SFTP viewing during market hours."""
        target.parent.mkdir(parents=True, exist_ok=True)
        with pd.ExcelWriter(target, engine="xlsxwriter") as writer:
            workbook = writer.book
            workbook.set_properties({"title": "GPA A股实时总览", "author": "GPA Stock Radar"})
            self._write_frame(
                workbook, "市场总览",
                pd.DataFrame([{"指标": key, "数值": value} for key, value in summary.items()]),
                "A股实时总览", "免费接口为轮询近实时；非Level-2"
            )
            candidate_columns = [column for column in (
                "code", "name", "price", "change_pct", "volume_ratio", "turnover_pct", "amount",
                "market_cap", "pe_dynamic", "pb", "score", "signal", "score_confidence",
                "score_basis", "risk", "reason", "data_source", "data_quality", "opening_noise", "fetched_at"
            ) if column in candidates]
            self._write_frame(
                workbook, "量比不小于4.9", candidates[candidate_columns],
                f"量比不小于 {self.settings.threshold:.1f} 实时候选",
                f"{_volume_note(health, self.settings.threshold)}；开盘噪声另行标记",
            )
            for sheet, title, frame in (
                ("行业强弱", "行业板块实时强弱", industries),
                ("概念强弱", "概念板块实时强弱", concepts),
            ):
                columns = [column for column in (
                    "code", "name", "change_pct", "turnover_pct", "breadth_pct", "up_count", "down_count",
                    "leader_name", "leader_change_pct", "score", "signal", "reason", "fetched_at"
                ) if column in frame]
                self._write_frame(workbook, sheet, frame[columns], title)
            health_frame = pd.DataFrame(
                [
                    {"模块": key, **(value if isinstance(value, dict) else {"状态": value})}
                    for key, value in (health or {}).items()
                ]
            )
            self._write_frame(
                workbook,
                "数据健康",
                health_frame,
                "数据源健康与字段可用性",
                "请先确认量比可用，再解读量比候选数量",
            )
        return target


def plot_board_strength(frame: pd.DataFrame, target: Path, title: str, top_n: int = 12) -> Path:
    _configure_fonts()
    target.parent.mkdir(parents=True, exist_ok=True)
    work = frame.dropna(subset=["name", "score"]).copy()
    work = pd.concat([work.head(top_n // 2), work.tail(top_n // 2)]).drop_duplicates("name")
    work = work.sort_values("score")
    colors = [_style_for_signal(value) for value in work.get("signal", "")]
    fig, ax = plt.subplots(figsize=(12, 7), facecolor=BACKGROUND)
    ax.set_facecolor(PANEL)
    ax.barh(work["name"], work["score"], color=colors, alpha=0.95)
    ax.axvline(50, color=GRID, linewidth=1, linestyle="--")
    for index, (_, row) in enumerate(work.iterrows()):
        ax.text(min(float(row["score"]) + 1, 97), index, f'{row["score"]:.1f}  {row.get("change_pct", float("nan")):.2f}%', color=colors[index], va="center", fontsize=9)
    ax.set_xlim(0, 105)
    ax.set_title(title, color=WHITE, fontsize=16, fontweight="bold", pad=16)
    ax.set_xlabel("综合评分（0–100）", color=GREY)
    ax.tick_params(axis="x", colors=GREY)
    ax.tick_params(axis="y", colors=WHITE)
    ax.grid(axis="x", color=GRID, alpha=0.45)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    fig.text(0.01, 0.01, f"蓝=好/偏强　白=坏/偏弱　灰=中性　北京时间 {now_cn():%Y-%m-%d %H:%M:%S}", color=GREY, fontsize=9)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    fig.savefig(target, dpi=160, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return target


def plot_volume_candidates(
    frame: pd.DataFrame,
    target: Path,
    threshold: float,
    empty_message: str = "",
) -> Path:
    _configure_fonts()
    target.parent.mkdir(parents=True, exist_ok=True)
    columns = [column for column in ("code", "name", "price", "change_pct", "volume_ratio", "turnover_pct", "score", "signal") if column in frame]
    work = frame[columns].head(25).copy()
    labels = [COLUMN_LABELS.get(column, column) for column in columns]
    fig, ax = plt.subplots(figsize=(15, 9), facecolor=BACKGROUND)
    ax.set_facecolor(BACKGROUND)
    ax.axis("off")
    ax.set_title(f"A股量比不小于 {threshold:.1f} 实时候选", color=WHITE, fontsize=18, fontweight="bold", pad=20)
    if work.empty:
        ax.text(
            0.5,
            0.5,
            empty_message or "当前无候选（量比字段已正常获取并完成筛选）",
            ha="center",
            va="center",
            color=ORANGE if empty_message else GREY,
            fontsize=14,
            wrap=True,
        )
    else:
        cell_text = []
        for _, row in work.iterrows():
            values: list[str] = []
            for column in columns:
                value = row[column]
                if isinstance(value, (float, np.floating)):
                    values.append(f"{value:.2f}")
                else:
                    values.append(str(value))
            cell_text.append(values)
        table = ax.table(cellText=cell_text, colLabels=labels, cellLoc="center", colLoc="center", loc="center", bbox=[0, 0.04, 1, 0.89])
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        for (row_index, column_index), cell in table.get_celld().items():
            cell.set_edgecolor(GRID)
            if row_index == 0:
                cell.set_facecolor("#163B5C")
                cell.get_text().set_color(WHITE)
                cell.get_text().set_weight("bold")
            else:
                cell.set_facecolor(PANEL)
                signal = work.iloc[row_index - 1].get("signal", "")
                cell.get_text().set_color(_style_for_signal(signal))
    fig.text(0.01, 0.015, f"免费接口为轮询近实时；开盘前5分钟需谨慎。北京时间 {now_cn():%Y-%m-%d %H:%M:%S}", color=GREY, fontsize=9)
    fig.savefig(target, dpi=160, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return target


def plot_valuation_percentiles(frame: pd.DataFrame, target: Path, title: str = "申万一级行业 PE 历史分位") -> Path:
    _configure_fonts()
    target.parent.mkdir(parents=True, exist_ok=True)
    work = frame.dropna(subset=["name", "pe_percentile"]).sort_values("pe_percentile").copy()
    height = max(7, min(22, 0.34 * len(work) + 2))
    colors = [_style_for_signal(value) for value in work.get("signal", "")]
    fig, ax = plt.subplots(figsize=(14, height), facecolor=BACKGROUND)
    ax.set_facecolor(PANEL)
    ax.barh(work["name"], work["pe_percentile"], color=colors)
    ax.axvline(30, color=BLUE, linestyle="--", linewidth=1)
    ax.axvline(70, color=WHITE, linestyle="--", linewidth=1)
    for index, (_, row) in enumerate(work.iterrows()):
        ax.text(min(row["pe_percentile"] + 1, 96), index, f'{row["pe_percentile"]:.1f}%｜PE {row["pe"]:.1f}', color=colors[index], va="center", fontsize=8)
    ax.set_xlim(0, 105)
    ax.set_title(title, color=WHITE, fontsize=16, fontweight="bold", pad=16)
    ax.set_xlabel("当前 PE 在历史区间内的分位（%）", color=GREY)
    ax.tick_params(axis="x", colors=GREY)
    ax.tick_params(axis="y", colors=WHITE, labelsize=8)
    ax.grid(axis="x", color=GRID, alpha=0.4)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    fig.text(0.01, 0.01, "蓝=低分位（≤30%）　白=高分位（≥70%）　周期行业需结合盈利周期", color=GREY, fontsize=9)
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig(target, dpi=160, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return target


def plot_live_overview(
    summary: dict[str, Any],
    candidates: pd.DataFrame,
    industries: pd.DataFrame,
    concepts: pd.DataFrame,
    target: Path,
    threshold: float,
    volume_message: str = "",
) -> Path:
    _configure_fonts()
    target.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(2, 2, figsize=(18, 11), facecolor=BACKGROUND)
    for ax in axes.flat:
        ax.set_facecolor(PANEL)
        for spine in ax.spines.values():
            spine.set_color(GRID)

    ax = axes[0, 0]
    ax.axis("off")
    ax.set_title("市场广度与成交", color=WHITE, fontsize=15, fontweight="bold")
    metrics = [
        ("上涨 / 下跌", f"{summary.get('up', '—')} / {summary.get('down', '—')}"),
        ("上涨占比", f"{summary.get('breadth_pct', '—')}%"),
        ("中位涨幅", f"{summary.get('median_change_pct', '—')}%"),
        ("成交额", f"{summary.get('total_amount_yi', '—')} 亿元"),
        ("近似涨停 / 跌停", f"{summary.get('limit_up_approx', '—')} / {summary.get('limit_down_approx', '—')}"),
        (
            "量比候选",
            f"{len(candidates)} 只（不小于{threshold:.1f}）"
            if summary.get("volume_ratio_available", True)
            else "未执行（当前源无真实量比）",
        ),
    ]
    for index, (label, value) in enumerate(metrics):
        y = 0.88 - index * 0.14
        ax.text(0.08, y, label, color=GREY, fontsize=12, transform=ax.transAxes)
        ax.text(0.52, y, value, color=BLUE if index in {1, 5} else WHITE, fontsize=14, fontweight="bold", transform=ax.transAxes)

    ax = axes[0, 1]
    work = candidates.head(12).sort_values("volume_ratio") if "volume_ratio" in candidates else pd.DataFrame()
    if not work.empty:
        colors = [_style_for_signal(value) for value in work.get("signal", pd.Series("", index=work.index))]
        ax.barh(work["name"], work["volume_ratio"], color=colors)
        for index, (_, row) in enumerate(work.iterrows()):
            ax.text(row["volume_ratio"] + 0.08, index, f'{row["volume_ratio"]:.2f}｜{row.get("change_pct", 0):.2f}%', color=colors[index], va="center", fontsize=8)
    else:
        ax.text(
            0.5,
            0.5,
            volume_message or "当前无量比候选（已完成筛选）",
            color=ORANGE if volume_message else GREY,
            ha="center",
            va="center",
            wrap=True,
            transform=ax.transAxes,
        )
    ax.set_title(f"量比不小于 {threshold:.1f} Top 12", color=WHITE, fontsize=15, fontweight="bold")
    ax.tick_params(axis="x", colors=GREY)
    ax.tick_params(axis="y", colors=WHITE, labelsize=9)
    ax.grid(axis="x", color=GRID, alpha=0.35)

    for ax, board, title in (
        (axes[1, 0], industries, "行业强弱 Top 10"),
        (axes[1, 1], concepts, "概念强弱 Top 10"),
    ):
        work = board.head(10).sort_values("score") if "score" in board else pd.DataFrame()
        if not work.empty:
            colors = [_style_for_signal(value) for value in work.get("signal", pd.Series("", index=work.index))]
            ax.barh(work["name"], work["score"], color=colors)
            for index, (_, row) in enumerate(work.iterrows()):
                ax.text(min(row["score"] + 1, 97), index, f'{row["score"]:.1f}', color=colors[index], va="center", fontsize=8)
        ax.set_xlim(0, 105)
        ax.set_title(title, color=WHITE, fontsize=15, fontweight="bold")
        ax.tick_params(axis="x", colors=GREY)
        ax.tick_params(axis="y", colors=WHITE, labelsize=9)
        ax.grid(axis="x", color=GRID, alpha=0.35)

    fig.suptitle("GPA A股实时分析总览", color=WHITE, fontsize=20, fontweight="bold", y=0.99)
    fig.text(0.01, 0.01, f"蓝=好/偏强　白=坏/偏弱　灰=中性　橙=异常｜免费轮询近实时｜北京时间 {now_cn():%Y-%m-%d %H:%M:%S}", color=GREY, fontsize=9)
    fig.tight_layout(rect=(0, 0.035, 1, 0.96), h_pad=2.0, w_pad=1.5)
    fig.savefig(target, dpi=160, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return target


def publish_latest(source: Path, latest_dir: Path) -> Path:
    latest_dir.mkdir(parents=True, exist_ok=True)
    target = latest_dir / source.name
    temporary = latest_dir / f".{source.name}.tmp"
    shutil.copy2(source, temporary)
    temporary.replace(target)
    return target
