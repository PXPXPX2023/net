#!/usr/bin/env bash
set -Eeuo pipefail
umask 0027

APP_ROOT=/opt/gpa-stock-radar
APP_DIR="$APP_ROOT/app"
VENV_DIR="$APP_ROOT/venv"
CONFIG_DIR=/etc/gpa-stock-radar
DATA_DIR=/var/lib/gpa-stock-radar
LOG_DIR=/var/log/gpa-stock-radar
SERVICE_USER=gparadar
SOURCE_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
BUNDLE_PROFILE=$(tr -d '[:space:]' < "$SOURCE_DIR/BUNDLE_PROFILE")
PROFILE_CONFIG="$SOURCE_DIR/profiles/$BUNDLE_PROFILE/config.yaml"
RESTORE_ARCHIVE=
SKIP_APT=0
NO_START=0
FRESH_CONFIG=0

usage() {
    printf '%s\n' \
        '用法：sudo bash install.sh [选项]' \
        '  --fresh-config                     备份旧配置并启用本安装包的全新区域配置' \
        '  --restore /绝对路径/backup.tar.zst  安装后恢复迁移备份' \
        '  --skip-apt                         跳过 apt 安装（依赖已准备时）' \
        '  --no-start                         安装但不启动定时服务' \
        '  -h, --help                         显示帮助'
}

while (($#)); do
    case "$1" in
        --restore)
            [[ $# -ge 2 ]] || { printf '错误：--restore 缺少路径\n' >&2; exit 2; }
            RESTORE_ARCHIVE=$2
            shift 2
            ;;
        --fresh-config)
            FRESH_CONFIG=1
            shift
            ;;
        --skip-apt)
            SKIP_APT=1
            shift
            ;;
        --no-start)
            NO_START=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            printf '未知选项：%s\n' "$1" >&2
            usage >&2
            exit 2
            ;;
    esac
done

if [[ ${EUID} -ne 0 ]]; then
    printf '请使用 root 权限运行：sudo bash install.sh\n' >&2
    exit 1
fi

if [[ "$BUNDLE_PROFILE" != overseas && "$BUNDLE_PROFILE" != china ]]; then
    printf '安装包区域标记无效：%s\n' "$BUNDLE_PROFILE" >&2
    exit 1
fi
if [[ ! -r "$PROFILE_CONFIG" ]]; then
    printf '安装包缺少区域配置：%s\n' "$PROFILE_CONFIG" >&2
    exit 1
fi

CURRENT_PROFILE=
if [[ -r "$CONFIG_DIR/profile" ]]; then
    CURRENT_PROFILE=$(tr -d '[:space:]' < "$CONFIG_DIR/profile")
fi
if [[ -n "$CURRENT_PROFILE" && "$CURRENT_PROFILE" != "$BUNDLE_PROFILE" && $FRESH_CONFIG -eq 0 ]]; then
    printf '当前配置是 %s，本安装包是 %s。\n' "$CURRENT_PROFILE" "$BUNDLE_PROFILE" >&2
    printf '如要安全切换，请重新执行并加入 --fresh-config；旧配置会先备份。\n' >&2
    exit 2
fi
if [[ -e "$CONFIG_DIR/config.yaml" && -z "$CURRENT_PROFILE" && $FRESH_CONFIG -eq 0 ]]; then
    printf '提示：检测到旧版自定义配置，将继续保留。要启用新的 %s 配置，请使用 --fresh-config。\n' "$BUNDLE_PROFILE"
fi

systemctl stop gpa-collector.service gpa-daily.timer gpa-finance.timer 2>/dev/null || true

if [[ -n "$RESTORE_ARCHIVE" ]]; then
    RESTORE_ARCHIVE=$(realpath -e -- "$RESTORE_ARCHIVE") || {
        printf '找不到迁移备份：%s\n' "$RESTORE_ARCHIVE" >&2
        exit 1
    }
fi

if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    source /etc/os-release
    if [[ ${ID:-} == debian && ${VERSION_ID:-0} != 12 && ${VERSION_ID:-0} != 13 ]]; then
        printf '提示：本安装包重点测试 Debian 12/13，当前为 %s %s。\n' "${ID:-unknown}" "${VERSION_ID:-unknown}"
    fi
fi

printf '安装区域：%s\n' "$BUNDLE_PROFILE"
printf '1/8 安装系统依赖……\n'
if [[ $SKIP_APT -eq 0 ]]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    apt-get install -y --no-install-recommends \
        ca-certificates curl fonts-noto-cjk gcc g++ libffi-dev libssl-dev \
        logrotate python3 python3-dev python3-pip python3-venv rsync sqlite3 tar zstd
fi

printf '2/8 创建专用账户和目录……\n'
if ! getent passwd "$SERVICE_USER" >/dev/null; then
    useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
fi
install -d -o root -g "$SERVICE_USER" -m 0750 "$APP_ROOT" "$CONFIG_DIR"
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" -m 2770 \
    "$DATA_DIR" "$DATA_DIR/db" "$DATA_DIR/cache" "$DATA_DIR/cache/matplotlib" \
    "$DATA_DIR/minute" "$DATA_DIR/financial" "$DATA_DIR/state" "$DATA_DIR/backups" \
    "$DATA_DIR/reports" "$DATA_DIR/reports/latest" "$DATA_DIR/reports/daily" \
    "$DATA_DIR/reports/financial" "$LOG_DIR"

printf '3/8 安装程序代码……\n'
install -d -o root -g "$SERVICE_USER" -m 0750 "$APP_DIR"
rsync -a --delete \
    --exclude '.git' --exclude '__pycache__' --exclude '.pytest_cache' \
    --exclude 'build' --exclude '*.egg-info' \
    "$SOURCE_DIR/" "$APP_DIR/"
chown -R root:"$SERVICE_USER" "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 0750 {} +
find "$APP_DIR" -type f -exec chmod 0640 {} +
chmod 0750 "$APP_DIR/install.sh" "$APP_DIR/scripts/gpa-launcher"

printf '4/8 创建 Python 3.11 虚拟环境……\n'
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    python3 -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/python" -m pip install --upgrade pip setuptools wheel
"$VENV_DIR/bin/python" -m pip install --upgrade "$APP_DIR"
chown -R root:"$SERVICE_USER" "$VENV_DIR"
chmod -R g+rX "$VENV_DIR"

printf '5/8 安装区域配置并保留用户资料……\n'
HAS_OLD_CONFIG=0
for name in config.yaml scoring.yaml watchlist.csv secrets.env profile; do
    if [[ -e "$CONFIG_DIR/$name" ]]; then
        HAS_OLD_CONFIG=1
        break
    fi
done
if [[ $FRESH_CONFIG -eq 1 && $HAS_OLD_CONFIG -eq 1 ]]; then
    CONFIG_BACKUP="$CONFIG_DIR/backups/$(date +%Y%m%d-%H%M%S)-before-$BUNDLE_PROFILE"
    install -d -o root -g "$SERVICE_USER" -m 0750 "$CONFIG_BACKUP"
    for name in config.yaml scoring.yaml watchlist.csv secrets.env profile; do
        if [[ -e "$CONFIG_DIR/$name" ]]; then
            cp -a -- "$CONFIG_DIR/$name" "$CONFIG_BACKUP/$name"
        fi
    done
    printf '旧配置已备份到：%s\n' "$CONFIG_BACKUP"
fi

if [[ $FRESH_CONFIG -eq 1 || ! -e "$CONFIG_DIR/config.yaml" ]]; then
    install -o root -g "$SERVICE_USER" -m 0640 "$PROFILE_CONFIG" "$CONFIG_DIR/config.yaml"
    install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/config/scoring.yaml" "$CONFIG_DIR/scoring.yaml"
    install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/BUNDLE_PROFILE" "$CONFIG_DIR/profile"
else
    if [[ ! -e "$CONFIG_DIR/scoring.yaml" ]]; then
        install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/config/scoring.yaml" "$CONFIG_DIR/scoring.yaml"
    fi
fi
if [[ ! -e "$CONFIG_DIR/watchlist.csv" ]]; then
    install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/config/watchlist.csv" "$CONFIG_DIR/watchlist.csv"
fi
if [[ ! -e "$CONFIG_DIR/secrets.env" ]]; then
    install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/config/secrets.env.example" "$CONFIG_DIR/secrets.env"
fi
install -o root -g root -m 0755 "$SOURCE_DIR/scripts/gpa-launcher" /usr/local/bin/gpa

printf '6/8 安装 systemd 与日志配置……\n'
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-collector.service" /etc/systemd/system/
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-daily.service" /etc/systemd/system/
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-daily.timer" /etc/systemd/system/
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-finance.service" /etc/systemd/system/
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-finance.timer" /etc/systemd/system/
install -o root -g root -m 0644 "$SOURCE_DIR/systemd/gpa-stock-radar.logrotate" /etc/logrotate.d/gpa-stock-radar
systemctl daemon-reload

printf '7/8 恢复数据并设置权限……\n'
if [[ -n "$RESTORE_ARCHIVE" ]]; then
    systemctl stop gpa-collector.service 2>/dev/null || true
    /usr/local/bin/gpa restore "$RESTORE_ARCHIVE"
    if [[ $FRESH_CONFIG -eq 1 ]]; then
        install -o root -g "$SERVICE_USER" -m 0640 "$PROFILE_CONFIG" "$CONFIG_DIR/config.yaml"
        install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/config/scoring.yaml" "$CONFIG_DIR/scoring.yaml"
        install -o root -g "$SERVICE_USER" -m 0640 "$SOURCE_DIR/BUNDLE_PROFILE" "$CONFIG_DIR/profile"
        printf '迁移数据已恢复；区域主配置重新设为：%s\n' "$BUNDLE_PROFILE"
    fi
fi
chown -R "$SERVICE_USER":"$SERVICE_USER" "$DATA_DIR" "$LOG_DIR"
chmod -R g+rwX "$DATA_DIR" "$LOG_DIR"
find "$DATA_DIR" "$LOG_DIR" -type d -exec chmod g+s {} +

if [[ -n ${SUDO_USER:-} && ${SUDO_USER} != root ]] && id "$SUDO_USER" >/dev/null 2>&1; then
    usermod -a -G "$SERVICE_USER" "$SUDO_USER"
fi

printf '8/8 检查并启动……\n'
set +e
runuser -u "$SERVICE_USER" -- /usr/local/bin/gpa doctor
DOCTOR_STATUS=$?
set -e
if [[ $NO_START -eq 0 ]]; then
    systemctl enable --now gpa-collector.service gpa-daily.timer gpa-finance.timer
else
    systemctl enable gpa-collector.service gpa-daily.timer gpa-finance.timer
fi

printf '\n安装完成。\n'
printf '当前版本：'
/usr/local/bin/gpa --version
printf '区域配置：%s\n' "$BUNDLE_PROFILE"
printf '实时界面：gpa\n'
printf '联网检查：gpa doctor --network\n'
printf '立即采集：sudo -u %s gpa once\n' "$SERVICE_USER"
printf '盘后报告：sudo -u %s gpa daily\n' "$SERVICE_USER"
printf '报告目录：%s/reports/latest\n' "$DATA_DIR"
printf '完整迁移：sudo -u %s gpa backup --full\n' "$SERVICE_USER"
if [[ -n ${SUDO_USER:-} && ${SUDO_USER} != root ]]; then
    printf '请重新登录 SSH 一次，使 %s 的 %s 组权限生效。\n' "$SUDO_USER" "$SERVICE_USER"
fi
if [[ $DOCTOR_STATUS -ne 0 ]]; then
    printf '提示：依赖或目录检查存在失败项，请查看上方输出；服务会继续重试。\n'
fi
